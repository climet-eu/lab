from .utils import total_variance

__all__ = ["total_variance"]
