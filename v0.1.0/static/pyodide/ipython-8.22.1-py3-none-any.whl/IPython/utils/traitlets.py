
from warnings import warn

warn("IPython.utils.traitlets has moved to a top-level traitlets package.", stacklevel=2)

from traitlets import *
