# Do not change! Do not track in version control!
__version__ = "1.4.7"
