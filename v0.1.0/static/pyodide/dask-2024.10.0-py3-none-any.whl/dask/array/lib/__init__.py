from __future__ import annotations

from dask.array.lib import stride_tricks
