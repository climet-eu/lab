.. cf_units documentation master file, created by
   sphinx-quickstart on Thu Jan 21 12:03:35 2016.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

The cf-units documentation
==========================

.. automodule:: cf_units

Contents:

.. toctree::
    unit
    utilities

cf-units is part of SciTools, for more information see https://scitools.org.uk/.
For **cf-units 2.0** and earlier documentation please see the
`legacy documentation <https://scitools.org.uk/cf-units/docs/v2.0/>`_.


Indices and tables
------------------

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
