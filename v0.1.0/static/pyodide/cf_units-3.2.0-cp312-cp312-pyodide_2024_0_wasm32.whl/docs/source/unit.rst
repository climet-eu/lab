.. currentmodule:: cf_units

The Unit Class
==============

The primary functionality of ``cf_units`` is supplied by the :class:`~cf_units.Unit` class:

.. autoclass:: Unit
   :members:
