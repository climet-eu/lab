from threading import Lock

netcdf_lock = Lock()
