"""
Platform independent script to download all the
`scipy.datasets` module data files.
This doesn't require a full scipy build.

Run: python _download_all.py <download_dir>
"""

from scipy._lib._array_api import xp_capabilities

import argparse
try:
    import pooch
except ImportError:
    pooch = None


if __spec__.parent is None or __spec__.parent == '':
    # Running as python script, use absolute import
    import _registry  # type: ignore
else:
    # Running as python module, use relative import
    from . import _registry


@xp_capabilities(out_of_scope=True)
def download_all(path=None):
    """
    Utility method to download all the dataset files
    for `scipy.datasets` module.

    Parameters
    ----------
    path : str, optional
        Directory path to download all the dataset files.
        If None, default to the system cache_dir detected by pooch.

    Examples
    --------
    Download the datasets to the default cache location:

    >>> from scipy import datasets
    >>> datasets.download_all()

    Download the datasets to the current directory:

    >>> datasets.download_all(".")

    """
    if pooch is None:
        raise ImportError("Missing optional dependency 'pooch' required "
                          "for scipy.datasets module. Please use pip or "
                          "conda to install 'pooch'.")
    if path is None:
        path = pooch.os_cache('scipy-data')
    # https://github.com/scipy/scipy/issues/21879
    downloader = pooch.HTTPDownloader(headers={"User-Agent": "SciPy"})
    for dataset_name, dataset_hash in _registry.registry.items():
        pooch.retrieve(url=_registry.registry_urls[dataset_name],
                       known_hash=dataset_hash,
                       fname=dataset_name, path=path, downloader=downloader)


def main():
    parser = argparse.ArgumentParser(description='Download SciPy data files.')
    parser.add_argument("path", nargs='?', type=str,
                        default=pooch.os_cache('scipy-data'),
                        help="Directory path to download all the data files.")
    args = parser.parse_args()
    download_all(args.path)


if __name__ == "__main__":
    main()
