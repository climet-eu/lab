/*
 * (C) Copyright 2011- ECMWF.
 *
 * This software is licensed under the terms of the Apache Licence Version 2.0
 * which can be obtained at http://www.apache.org/licenses/LICENSE-2.0.
 * In applying this licence, ECMWF does not waive the privileges and immunities
 * granted to it by virtue of its status as an intergovernmental organisation nor
 * does it submit to any jurisdiction.
 */

#ifndef ECKIT_ecbuild_config_h
#define ECKIT_ecbuild_config_h

/* ecbuild info */

#ifndef ECBUILD_VERSION_STR
#define ECBUILD_VERSION_STR "3.7.0"
#endif
#ifndef ECBUILD_VERSION
#define ECBUILD_VERSION "3.7.0"
#endif
#ifndef ECBUILD_MACROS_DIR
#define ECBUILD_MACROS_DIR  "/src/pyodide-recipes/packages/libeckit/build/libeckit-2.1.0/ecbuild/cmake"
#endif

/* config info */

#define ECKIT_OS_NAME          "Emscripten-1"
#define ECKIT_OS_BITS          32
#define ECKIT_OS_BITS_STR      "32"
#define ECKIT_OS_STR           "UNKNOWN.32"
#define ECKIT_OS_VERSION       "1"
#define ECKIT_SYS_PROCESSOR    "x86"

#define ECKIT_BUILD_TIMESTAMP  "20260907082933"
#define ECKIT_BUILD_TYPE       "RelWithDebInfo"

#define ECKIT_C_COMPILER_ID      "Clang"
#define ECKIT_C_COMPILER_VERSION "23.0.0"

#define ECKIT_CXX_COMPILER_ID      "Clang"
#define ECKIT_CXX_COMPILER_VERSION "23.0.0"

#define ECKIT_C_COMPILER       "/src/emsdk/emsdk/upstream/emscripten/emcc"
#define ECKIT_C_FLAGS          "-fwasm-exceptions -O2 -g0 -fPIC -fwasm-exceptions -sSUPPORT_LONGJMP=wasm -I/src/cpython/installs/python-3.14.2/include/python3.14 -Oz -O2 -g0 -fPIC -fwasm-exceptions -sSUPPORT_LONGJMP=wasm -I/src/cpython/installs/python-3.14.2/include/python3.14 -Oz -O2 -g0 -fPIC -fwasm-exceptions -sSUPPORT_LONGJMP=wasm -I/src/cpython/installs/python-3.14.2/include/python3.14 -Oz -O2 -g0 -fPIC -fwasm-exceptions -sSUPPORT_LONGJMP=wasm -I/src/cpython/installs/python-3.14.2/include/python3.14 -Oz -O2 -g0 -fPIC -fwasm-exceptions -sSUPPORT_LONGJMP=wasm -I/src/cpython/installs/python-3.14.2/include/python3.14 -Oz -pipe -O2 -g -DNDEBUG"

#define ECKIT_CXX_COMPILER     "/src/emsdk/emsdk/upstream/emscripten/em++"
#define ECKIT_CXX_FLAGS        "-fwasm-exceptions -O2 -g0 -fPIC -fwasm-exceptions -sSUPPORT_LONGJMP=wasm -Oz -O2 -g0 -fPIC -fwasm-exceptions -sSUPPORT_LONGJMP=wasm -Oz -O2 -g0 -fPIC -fwasm-exceptions -sSUPPORT_LONGJMP=wasm -Oz -O2 -g0 -fPIC -fwasm-exceptions -sSUPPORT_LONGJMP=wasm -Oz -O2 -g0 -fPIC -fwasm-exceptions -sSUPPORT_LONGJMP=wasm -Oz -pipe -Wall -Wextra -Wno-unused-parameter -Wno-unused-variable -Wno-sign-compare -O2 -g -DNDEBUG"

/* Needed for finding per package config files */

#define ECKIT_INSTALL_DIR       "/src/pyodide-recipes/packages/.libs"
#define ECKIT_INSTALL_BIN_DIR   "/src/pyodide-recipes/packages/.libs/bin"
#define ECKIT_INSTALL_LIB_DIR   "/src/pyodide-recipes/packages/.libs/lib"
#define ECKIT_INSTALL_DATA_DIR  "/src/pyodide-recipes/packages/.libs/share/eckit"

#define ECKIT_DEVELOPER_SRC_DIR "/src/pyodide-recipes/packages/libeckit/build/libeckit-2.1.0"
#define ECKIT_DEVELOPER_BIN_DIR "/src/pyodide-recipes/packages/libeckit/build/libeckit-2.1.0/build"

/* Fortran support */

#if 0

#define ECKIT_Fortran_COMPILER_ID      ""
#define ECKIT_Fortran_COMPILER_VERSION ""

#define ECKIT_Fortran_COMPILER ""
#define ECKIT_Fortran_FLAGS    ""

#endif

#endif /* ECKIT_ecbuild_config_h */
