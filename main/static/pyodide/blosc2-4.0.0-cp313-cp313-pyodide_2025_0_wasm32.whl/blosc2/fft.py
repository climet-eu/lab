#######################################################################
# Copyright (c) 2019-present, Blosc Development Team <blosc@blosc.org>
# All rights reserved.
#
# SPDX-License-Identifier: BSD-3-Clause
#######################################################################


def fft():
    raise NotImplementedError


def ifft():
    raise NotImplementedError


def fftn():
    raise NotImplementedError


def ifftn():
    raise NotImplementedError


def rfft():
    raise NotImplementedError


def irfft():
    raise NotImplementedError


def rfftn():
    raise NotImplementedError


def irfftn():
    raise NotImplementedError


def hfft():
    raise NotImplementedError


def ihfft():
    raise NotImplementedError


def fftfreq():
    raise NotImplementedError


def rfftfreq():
    raise NotImplementedError


def fftshift():
    raise NotImplementedError


def ifftshift():
    raise NotImplementedError
