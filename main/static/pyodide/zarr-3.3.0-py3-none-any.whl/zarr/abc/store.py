from __future__ import annotations

import asyncio
from abc import ABC, abstractmethod
from dataclasses import dataclass
from functools import partial
from itertools import starmap
from typing import TYPE_CHECKING, Literal, Protocol, runtime_checkable

if TYPE_CHECKING:
    from collections.abc import AsyncGenerator, AsyncIterator, Iterable, Sequence
    from types import TracebackType
    from typing import Any, Self

    from zarr.core.buffer import Buffer, BufferPrototype

__all__ = [
    "ByteGetter",
    "ByteSetter",
    "Store",
    "SupportsDeleteSync",
    "SupportsGetSync",
    "SupportsSetSync",
    "SupportsSyncStore",
    "SyncByteGetter",
    "SyncByteSetter",
    "set_or_delete",
]


@dataclass(frozen=True, slots=True)
class RangeByteRequest:
    """Request a specific byte range"""

    start: int
    """The start of the byte range request (inclusive)."""
    end: int
    """The end of the byte range request (exclusive)."""


@dataclass(frozen=True, slots=True)
class OffsetByteRequest:
    """Request all bytes starting from a given byte offset"""

    offset: int
    """The byte offset for the offset range request."""


@dataclass(frozen=True, slots=True)
class SuffixByteRequest:
    """Request up to the last `n` bytes"""

    suffix: int
    """The number of bytes from the suffix to request."""


type ByteRequest = RangeByteRequest | OffsetByteRequest | SuffixByteRequest


class Store(ABC):
    """
    Abstract base class for Zarr stores.
    """

    _read_only: bool
    _is_open: bool

    def __init__(self, *, read_only: bool = False) -> None:
        self._is_open = False
        self._read_only = read_only

    @classmethod
    async def open(cls, *args: Any, **kwargs: Any) -> Self:
        """
        Create and open the store.

        Parameters
        ----------
        *args : Any
            Positional arguments to pass to the store constructor.
        **kwargs : Any
            Keyword arguments to pass to the store constructor.

        Returns
        -------
        Store
            The opened store instance.
        """
        store = cls(*args, **kwargs)
        await store._open()
        return store

    def with_read_only(self, read_only: bool = False) -> Store:
        """
        Return a new store with a new read_only setting.

        The new store points to the same location with the specified new read_only state.
        The returned Store is not automatically opened, and this store is
        not automatically closed.

        Parameters
        ----------
        read_only
            If True, the store will be created in read-only mode. Defaults to False.

        Returns
        -------
            A new store of the same type with the new read only attribute.
        """
        raise NotImplementedError(
            f"with_read_only is not implemented for the {type(self)} store type."
        )

    def __enter__(self) -> Self:
        """Enter a context manager that will close the store upon exiting."""
        return self

    def __exit__(
        self,
        exc_type: type[BaseException] | None,
        exc_value: BaseException | None,
        traceback: TracebackType | None,
    ) -> None:
        """Close the store."""
        self.close()

    async def _open(self) -> None:
        """
        Open the store.

        Raises
        ------
        ValueError
            If the store is already open.
        """
        if self._is_open:
            raise ValueError("store is already open")
        self._is_open = True

    async def _ensure_open(self) -> None:
        """Open the store if it is not already open."""
        if not self._is_open:
            await self._open()

    async def is_empty(self, prefix: str) -> bool:
        """
        Check if the directory is empty.

        Parameters
        ----------
        prefix : str
            Prefix of keys to check.

        Returns
        -------
        bool
            True if the store is empty, False otherwise.
        """
        if not self.supports_listing:
            raise NotImplementedError
        if prefix != "" and not prefix.endswith("/"):
            prefix += "/"
        async for _ in self.list_prefix(prefix):
            return False
        return True

    async def clear(self) -> None:
        """
        Clear the store.

        Remove all keys and values from the store.
        """
        if not self.supports_deletes:
            raise NotImplementedError
        if not self.supports_listing:
            raise NotImplementedError
        self._check_writable()
        await self.delete_dir("")

    @property
    def read_only(self) -> bool:
        """Is the store read-only?"""
        return self._read_only

    def _check_writable(self) -> None:
        """Raise an exception if the store is not writable."""
        if self.read_only:
            raise ValueError("store was opened in read-only mode and does not support writing")

    @abstractmethod
    def __eq__(self, value: object) -> bool:
        """Equality comparison."""
        ...

    @abstractmethod
    async def get(
        self,
        key: str,
        prototype: BufferPrototype,
        byte_range: ByteRequest | None = None,
    ) -> Buffer | None:
        """Retrieve the value associated with a given key.

        Parameters
        ----------
        key : str
        prototype : BufferPrototype
            The prototype of the output buffer. Stores may support a default buffer prototype.
        byte_range : ByteRequest, optional
            ByteRequest may be one of the following. If not provided, all data associated with the key is retrieved.
            - RangeByteRequest(int, int): Request a specific range of bytes in the form (start, end). The end is exclusive. If the given range is zero-length or starts after the end of the object, an error will be returned. Additionally, if the range ends after the end of the object, the entire remainder of the object will be returned. Otherwise, the exact requested range will be returned.
            - OffsetByteRequest(int): Request all bytes starting from a given byte offset. This is equivalent to bytes={int}- as an HTTP header.
            - SuffixByteRequest(int): Request the last int bytes. Note that here, int is the size of the request, not the byte offset. This is equivalent to bytes=-{int} as an HTTP header.

        Returns
        -------
        Buffer
        """
        ...

    @abstractmethod
    async def get_partial_values(
        self,
        prototype: BufferPrototype,
        key_ranges: Iterable[tuple[str, ByteRequest | None]],
    ) -> list[Buffer | None]:
        """Retrieve possibly partial values from given key_ranges.

        Parameters
        ----------
        prototype : BufferPrototype
            The prototype of the output buffer. Stores may support a default buffer prototype.
        key_ranges : Iterable[tuple[str, tuple[int | None, int | None]]]
            Ordered set of key, range pairs, a key may occur multiple times with different ranges

        Returns
        -------
        list of values, in the order of the key_ranges, may contain null/none for missing keys
        """
        ...

    @abstractmethod
    async def exists(self, key: str) -> bool:
        """Check if a key exists in the store.

        Parameters
        ----------
        key : str

        Returns
        -------
        bool
        """
        ...

    @property
    @abstractmethod
    def supports_writes(self) -> bool:
        """Does the store support writes?"""
        ...

    @abstractmethod
    async def set(self, key: str, value: Buffer) -> None:
        """Store a (key, value) pair.

        Parameters
        ----------
        key : str
        value : Buffer
        """
        ...

    async def set_if_not_exists(self, key: str, value: Buffer) -> None:
        """
        Store a key to ``value`` if the key is not already present.

        Parameters
        ----------
        key : str
        value : Buffer
        """
        # Note for implementers: the default implementation provided here
        # is not safe for concurrent writers. There's a race condition between
        # the `exists` check and the `set` where another writer could set some
        # value at `key` or delete `key`.
        if not await self.exists(key):
            await self.set(key, value)

    async def _set_many(self, values: Iterable[tuple[str, Buffer]]) -> None:
        """
        Insert multiple (key, value) pairs into storage.
        """
        await asyncio.gather(*starmap(self.set, values))

    @property
    def supports_consolidated_metadata(self) -> bool:
        """
        Does the store support consolidated metadata?.

        If it doesn't an error will be raised on requests to consolidate the metadata.
        Returning `False` can be useful for stores which implement their own
        consolidation mechanism outside of the zarr-python implementation.
        """

        return True

    @property
    @abstractmethod
    def supports_deletes(self) -> bool:
        """Does the store support deletes?"""
        ...

    @abstractmethod
    async def delete(self, key: str) -> None:
        """Remove a key from the store

        Parameters
        ----------
        key : str
        """
        ...

    @property
    def supports_partial_writes(self) -> Literal[False]:
        """Does the store support partial writes?

        Partial writes are no longer used by Zarr, so this is always false.
        """
        return False

    @property
    @abstractmethod
    def supports_listing(self) -> bool:
        """Does the store support listing?"""
        ...

    @abstractmethod
    def list(self) -> AsyncIterator[str]:
        """Retrieve all keys in the store.

        Returns
        -------
        AsyncIterator[str]
        """
        # This method should be async, like overridden methods in child classes.
        # However, that's not straightforward:
        # https://stackoverflow.com/questions/68905848

    @abstractmethod
    def list_prefix(self, prefix: str) -> AsyncIterator[str]:
        """
        Retrieve all keys in the store that begin with a given prefix. Keys are returned relative
        to the root of the store.

        Parameters
        ----------
        prefix : str

        Returns
        -------
        AsyncIterator[str]
        """
        # This method should be async, like overridden methods in child classes.
        # However, that's not straightforward:
        # https://stackoverflow.com/questions/68905848

    @abstractmethod
    def list_dir(self, prefix: str) -> AsyncIterator[str]:
        """
        Retrieve all keys and prefixes with a given prefix and which do not contain the character
        “/” after the given prefix.

        Parameters
        ----------
        prefix : str

        Returns
        -------
        AsyncIterator[str]
        """
        # This method should be async, like overridden methods in child classes.
        # However, that's not straightforward:
        # https://stackoverflow.com/questions/68905848

    async def delete_dir(self, prefix: str) -> None:
        """
        Remove all keys and prefixes in the store that begin with a given prefix.
        """
        if not self.supports_deletes:
            raise NotImplementedError
        if not self.supports_listing:
            raise NotImplementedError
        self._check_writable()
        if prefix != "" and not prefix.endswith("/"):
            prefix += "/"
        async for key in self.list_prefix(prefix):
            await self.delete(key)

    def close(self) -> None:
        """Close the store."""
        self._is_open = False

    async def _get_many(
        self, requests: Iterable[tuple[str, BufferPrototype, ByteRequest | None]]
    ) -> AsyncGenerator[tuple[str, Buffer | None], None]:
        """
        Retrieve a collection of objects from storage. In general this method does not guarantee
        that objects will be retrieved in the order in which they were requested, so this method
        yields tuple[str, Buffer | None] instead of just Buffer | None
        """
        for req in requests:
            yield (req[0], await self.get(*req))

    async def get_ranges(
        self,
        key: str,
        byte_ranges: Sequence[ByteRequest | None],
        *,
        prototype: BufferPrototype,
        max_concurrency: int = 10,
        max_gap_bytes: int = 1 << 20,  # 1 MiB
        max_coalesced_bytes: int = 16 << 20,  # 16 MiB
    ) -> AsyncIterator[Sequence[tuple[int, Buffer | None]]]:
        """Read many byte ranges from `key`.

        Yields one batch per underlying I/O operation, each a sequence of
        `(input_index, Buffer | None)` tuples. Batches across yields arrive in
        completion order, not input order. The default implementation built
        into `Store` runs the coalescer over `self.get`, so subclasses get a
        working implementation for free; stores that have a more efficient
        backend (e.g. ranged HTTP, S3 byte-range fetches) should override.

        Parameters
        ----------
        key
            Storage key to read from.
        byte_ranges
            Input ranges. `None` means "the whole value".
        prototype
            Buffer prototype, forwarded to `self.get`.
        max_concurrency
            Maximum number of merged fetches in flight at once.
        max_gap_bytes
            Two `RangeByteRequest`s separated by at most this many bytes may
            be merged into one fetch.
        max_coalesced_bytes
            Upper bound on the size of a single merged fetch.

        Raises
        ------
        BaseExceptionGroup
            Failures from underlying fetches are reported as a
            `BaseExceptionGroup` (PEP 654) and should be handled with
            `except*`. Inner exceptions include `FileNotFoundError` if any
            fetch returns `None` (i.e. `key` is absent), and any exception
            raised by `self.get` for the corresponding range. Pending
            fetches are cancelled as soon as one task fails, so the group
            typically contains a single non-`CancelledError` exception even
            under high concurrency.
        """
        # Local import: zarr.core._coalesce imports symbols from this module.
        from zarr.core._coalesce import coalesced_get

        fetch = partial(self.get, key, prototype)
        async for group in coalesced_get(
            fetch,
            byte_ranges,
            max_concurrency=max_concurrency,
            max_gap_bytes=max_gap_bytes,
            max_coalesced_bytes=max_coalesced_bytes,
        ):
            yield group

    def get_ranges_sync(
        self,
        key: str,
        byte_ranges: Sequence[ByteRequest | None],
        *,
        prototype: BufferPrototype,
        max_gap_bytes: int = 1 << 20,  # 1 MiB
        max_coalesced_bytes: int = 16 << 20,  # 16 MiB
    ) -> Sequence[tuple[int, Buffer | None]]:
        """Synchronous, coalescing counterpart of `get_ranges`.

        Plans merged fetches with the same `coalesce_ranges` policy as the async
        path, then issues one synchronous `get_sync` per merged group (or per
        uncoalescable request) and slices results back into per-input buffers.
        Used by the sync codec pipeline's partial-shard reads so they get the
        same byte-range coalescing as the async path, without an event loop.

        Returns a list of `(input_index, Buffer | None)`. Raises
        `BaseExceptionGroup` containing a `FileNotFoundError` if the key is
        absent (matching `get_ranges`), so callers can handle a deleted shard
        uniformly across the sync and async paths.

        Requires the store to implement `get_sync` (`SupportsGetSync`).
        """
        from zarr.core._coalesce import coalesce_ranges

        if not isinstance(self, SupportsGetSync):
            raise TypeError(f"{type(self).__name__} does not support synchronous reads")

        groups, uncoalescable = coalesce_ranges(
            byte_ranges, max_gap_bytes=max_gap_bytes, max_coalesced_bytes=max_coalesced_bytes
        )
        results: list[tuple[int, Buffer | None]] = []
        errors: list[BaseException] = []

        def _get(req: ByteRequest | None) -> Buffer | None:
            return self.get_sync(key, prototype=prototype, byte_range=req)

        for idx, req in uncoalescable:
            buf = _get(req)
            if buf is None:
                errors.append(FileNotFoundError(key))
            else:
                results.append((idx, buf))

        for members in groups:
            if len(members) == 1:
                solo_idx, solo_req = members[0]
                buf = _get(solo_req)
                if buf is None:
                    errors.append(FileNotFoundError(key))
                else:
                    results.append((solo_idx, buf))
                continue
            start = members[0][1].start
            end = max(r.end for _, r in members)
            big = _get(RangeByteRequest(start, end))
            if big is None:
                errors.append(FileNotFoundError(key))
                continue
            for member_idx, r in members:
                results.append((member_idx, big[r.start - start : r.end - start]))

        if errors:
            raise BaseExceptionGroup("chunk read failed", errors)
        return results

    async def getsize(self, key: str) -> int:
        """
        Return the size, in bytes, of a value in a Store.

        Parameters
        ----------
        key : str

        Returns
        -------
        nbytes : int
            The size of the value (in bytes).

        Raises
        ------
        FileNotFoundError
            When the given key does not exist in the store.
        """
        # Note to implementers: this default implementation is very inefficient since
        # it requires reading the entire object. Many systems will have ways to get the
        # size of an object without reading it.
        # avoid circular import
        from zarr.core.buffer.core import default_buffer_prototype

        value = await self.get(key, prototype=default_buffer_prototype())
        if value is None:
            raise FileNotFoundError(key)
        return len(value)

    async def getsize_prefix(self, prefix: str) -> int:
        """
        Return the size, in bytes, of all values under a prefix.

        Parameters
        ----------
        prefix : str
            The prefix of the directory to measure.

        Returns
        -------
        nbytes : int
            The sum of the sizes of the values in the directory (in bytes).

        See Also
        --------
        zarr.Array.nbytes_stored
        Store.getsize

        Notes
        -----
        ``getsize_prefix`` is just provided as a potentially faster alternative to
        listing all the keys under a prefix calling [`Store.getsize`][zarr.abc.store.Store.getsize] on each.

        In general, ``prefix`` should be the path of an Array or Group in the Store.
        Implementations may differ on the behavior when some other ``prefix``
        is provided.
        """
        # TODO: Overlap listing keys with getsize calls.
        # Currently, we load the list of keys into memory and only then move
        # on to getting sizes. Ideally we would overlap those two, which should
        # improve tail latency and might reduce memory pressure (since not all keys
        # would be in memory at once).

        # avoid circular import
        from zarr.core.common import concurrent_map
        from zarr.core.config import config

        if prefix != "" and not prefix.endswith("/"):
            prefix += "/"
        keys = [(x,) async for x in self.list_prefix(prefix)]
        limit = config.get("async.concurrency")
        sizes = await concurrent_map(keys, self.getsize, limit=limit)
        return sum(sizes)


@runtime_checkable
class ByteGetter(Protocol):
    async def get(
        self, prototype: BufferPrototype, byte_range: ByteRequest | None = None
    ) -> Buffer | None: ...


@runtime_checkable
class ByteSetter(Protocol):
    async def get(
        self, prototype: BufferPrototype, byte_range: ByteRequest | None = None
    ) -> Buffer | None: ...

    async def set(self, value: Buffer) -> None: ...

    async def delete(self) -> None: ...

    async def set_if_not_exists(self, default: Buffer) -> None: ...


@runtime_checkable
class SyncByteGetter(Protocol):
    """A `ByteGetter` that can also fetch synchronously, without an event loop.

    Non-StorePath byte getters (e.g. the sharding codec's in-memory
    `_ShardingByteGetter`) implement this so a synchronous codec pipeline can
    take its sync fast path on them instead of scheduling one coroutine per
    chunk. Note that `StorePath` also *has* a `get_sync` method (so it matches
    this protocol structurally) but it only works when its store supports
    synchronous IO — callers gate `StorePath` on the store's `SupportsGetSync`
    instead of on this protocol.
    """

    def get_sync(
        self, prototype: BufferPrototype | None = None, byte_range: ByteRequest | None = None
    ) -> Buffer | None: ...


@runtime_checkable
class SyncByteSetter(SyncByteGetter, Protocol):
    """A `ByteSetter` that can also write synchronously. See `SyncByteGetter`."""

    def set_sync(self, value: Buffer) -> None: ...

    def delete_sync(self) -> None: ...


@runtime_checkable
class SupportsGetSync(Protocol):
    """Store protocol for synchronous reads (`get_sync`).

    The store sync surface is all-or-nothing: a store implementing any of the
    `*_sync` methods must implement all of them (`SupportsSyncStore`), because
    consumers mix sync reads, writes, and deletes within one operation.
    Capability-gated callers consult `_store_supports_sync_io` rather than the
    individual protocols.
    """

    def get_sync(
        self,
        key: str,
        *,
        prototype: BufferPrototype | None = None,
        byte_range: ByteRequest | None = None,
    ) -> Buffer | None: ...


@runtime_checkable
class SupportsSetSync(Protocol):
    """Store protocol for synchronous writes (`set_sync`).

    See `SupportsGetSync` for the all-or-nothing contract on the store sync
    surface.
    """

    def set_sync(self, key: str, value: Buffer) -> None: ...


@runtime_checkable
class SupportsDeleteSync(Protocol):
    """Store protocol for synchronous deletes (`delete_sync`).

    See `SupportsGetSync` for the all-or-nothing contract on the store sync
    surface.
    """

    def delete_sync(self, key: str) -> None: ...


@runtime_checkable
class SupportsSyncStore(SupportsGetSync, SupportsSetSync, SupportsDeleteSync, Protocol):
    """The full store sync surface: `get_sync`, `set_sync`, and `delete_sync`."""


def _store_supports_sync_io(store: object) -> bool:
    """Whether `store` can serve the full synchronous IO surface right now.

    Structural membership in `SupportsSyncStore` is necessary but not always
    sufficient: a store can present the `*_sync` methods while its ability to
    run them depends on runtime state the type system cannot see. Wrapper
    stores are the canonical case — `WrapperStore` delegates the sync methods
    to the store it wraps, so they only work when the wrapped store is itself
    sync-capable. Such stores opt out dynamically via a `_supports_sync_io`
    attribute/property (absent means capable).

    This is an interim, private convention pending a formal sync/async store
    architecture — the store-side twin of the codec-side `_sync_capable`
    convention consulted by `zarr.abc.codec._codec_supports_sync`.

    Synchronous IO is all-or-nothing: consumers such as the fused codec
    pipeline mix synchronous reads, writes, and deletes within one batch
    (e.g. a partial-chunk write reads existing bytes and an all-fill chunk is
    deleted), so a partial sync surface never satisfies this predicate.
    """
    return isinstance(store, SupportsSyncStore) and getattr(store, "_supports_sync_io", True)


async def set_or_delete(byte_setter: ByteSetter, value: Buffer | None) -> None:
    """Set or delete a value in a byte setter

    Parameters
    ----------
    byte_setter : ByteSetter
    value : Buffer | None

    Notes
    -----
    If value is None, the key will be deleted.
    """
    if value is None:
        await byte_setter.delete()
    else:
        await byte_setter.set(value)
