from __future__ import annotations

from typing import TYPE_CHECKING, cast

if TYPE_CHECKING:
    from collections.abc import AsyncGenerator, AsyncIterator, Iterable, Sequence
    from types import TracebackType
    from typing import Any, Self

    from zarr.abc.buffer import Buffer
    from zarr.abc.store import ByteRequest
    from zarr.core.buffer import BufferPrototype

from zarr.abc.store import (
    Store,
    SupportsDeleteSync,
    SupportsGetSync,
    SupportsSetSync,
    _store_supports_sync_io,
)


class WrapperStore[T_Store: Store](Store):
    """
    Store that wraps an existing Store.

    By default all of the store methods are delegated to the wrapped store instance, which is
    accessible via the ``._store`` attribute of this class.

    Use this class to modify or extend the behavior of the other store classes.
    """

    _store: T_Store

    def __init__(self, store: T_Store) -> None:
        self._store = store

    def _with_store(self, store: T_Store) -> Self:
        """
        Constructs a new instance of the wrapper store with the same details but a new store.
        """
        return type(self)(store=store)

    @classmethod
    async def open(cls: type[Self], store_cls: type[T_Store], *args: Any, **kwargs: Any) -> Self:
        store = store_cls(*args, **kwargs)
        await store._open()
        return cls(store=store)

    def with_read_only(self, read_only: bool = False) -> Self:
        return self._with_store(cast(T_Store, self._store.with_read_only(read_only)))

    def __enter__(self) -> Self:
        return self._with_store(self._store.__enter__())

    def __exit__(
        self,
        exc_type: type[BaseException] | None,
        exc_value: BaseException | None,
        traceback: TracebackType | None,
    ) -> None:
        return self._store.__exit__(exc_type, exc_value, traceback)

    async def _open(self) -> None:
        await self._store._open()

    async def _ensure_open(self) -> None:
        await self._store._ensure_open()

    async def is_empty(self, prefix: str) -> bool:
        return await self._store.is_empty(prefix)

    @property
    def _is_open(self) -> bool:
        return self._store._is_open

    @_is_open.setter
    def _is_open(self, value: bool) -> None:
        raise NotImplementedError("WrapperStore must be opened via the `_open` method")

    async def clear(self) -> None:
        return await self._store.clear()

    @property
    def read_only(self) -> bool:
        return self._store.read_only

    def _check_writable(self) -> None:
        return self._store._check_writable()

    def __eq__(self, value: object) -> bool:
        return type(self) is type(value) and self._store.__eq__(value._store)

    def __str__(self) -> str:
        return f"wrapping-{self._store}"

    def __repr__(self) -> str:
        return f"WrapperStore({self._store.__class__.__name__}, '{self._store}')"

    async def get(
        self, key: str, prototype: BufferPrototype, byte_range: ByteRequest | None = None
    ) -> Buffer | None:
        return await self._store.get(key, prototype, byte_range)

    async def get_partial_values(
        self,
        prototype: BufferPrototype,
        key_ranges: Iterable[tuple[str, ByteRequest | None]],
    ) -> list[Buffer | None]:
        return await self._store.get_partial_values(prototype, key_ranges)

    async def get_ranges(
        self,
        key: str,
        byte_ranges: Sequence[ByteRequest | None],
        *,
        prototype: BufferPrototype,
        max_concurrency: int | None = None,
        max_gap_bytes: int | None = None,
        max_coalesced_bytes: int | None = None,
    ) -> AsyncIterator[Sequence[tuple[int, Buffer | None]]]:
        """Forward `get_ranges` to the wrapped store.

        Default values for the coalescing kwargs are not declared here; the
        wrapped store decides them. `None` means "don't override the wrapped
        store's default".
        """
        kwargs: dict[str, int] = {}
        if max_concurrency is not None:
            kwargs["max_concurrency"] = max_concurrency
        if max_gap_bytes is not None:
            kwargs["max_gap_bytes"] = max_gap_bytes
        if max_coalesced_bytes is not None:
            kwargs["max_coalesced_bytes"] = max_coalesced_bytes
        async for group in self._store.get_ranges(key, byte_ranges, prototype=prototype, **kwargs):
            yield group

    async def exists(self, key: str) -> bool:
        return await self._store.exists(key)

    async def set(self, key: str, value: Buffer) -> None:
        await self._store.set(key, value)

    async def set_if_not_exists(self, key: str, value: Buffer) -> None:
        return await self._store.set_if_not_exists(key, value)

    async def _set_many(self, values: Iterable[tuple[str, Buffer]]) -> None:
        await self._store._set_many(values)

    @property
    def supports_writes(self) -> bool:
        return self._store.supports_writes

    @property
    def supports_deletes(self) -> bool:
        return self._store.supports_deletes

    @property
    def _supports_sync_io(self) -> bool:
        # The delegating `*_sync` methods below make every wrapper structurally
        # satisfy `SupportsSyncStore`; whether they can actually run depends on
        # the wrapped store, so forward its capability (see
        # `zarr.abc.store._store_supports_sync_io`).
        return _store_supports_sync_io(self._store)

    def get_sync(
        self,
        key: str,
        *,
        prototype: BufferPrototype | None = None,
        byte_range: ByteRequest | None = None,
    ) -> Buffer | None:
        """Forward `get_sync` to the wrapped store."""
        if not isinstance(self._store, SupportsGetSync):
            raise TypeError(f"Store {type(self._store).__name__} does not support synchronous get.")
        return self._store.get_sync(key, prototype=prototype, byte_range=byte_range)  # type: ignore[unreachable]

    def set_sync(self, key: str, value: Buffer) -> None:
        """Forward `set_sync` to the wrapped store."""
        if not isinstance(self._store, SupportsSetSync):
            raise TypeError(f"Store {type(self._store).__name__} does not support synchronous set.")
        self._store.set_sync(key, value)  # type: ignore[unreachable]

    def delete_sync(self, key: str) -> None:
        """Forward `delete_sync` to the wrapped store."""
        if not isinstance(self._store, SupportsDeleteSync):
            raise TypeError(
                f"Store {type(self._store).__name__} does not support synchronous delete."
            )
        self._store.delete_sync(key)  # type: ignore[unreachable]

    async def delete(self, key: str) -> None:
        await self._store.delete(key)

    @property
    def supports_listing(self) -> bool:
        return self._store.supports_listing

    def list(self) -> AsyncIterator[str]:
        return self._store.list()

    def list_prefix(self, prefix: str) -> AsyncIterator[str]:
        return self._store.list_prefix(prefix)

    def list_dir(self, prefix: str) -> AsyncIterator[str]:
        return self._store.list_dir(prefix)

    async def delete_dir(self, prefix: str) -> None:
        return await self._store.delete_dir(prefix)

    def close(self) -> None:
        self._store.close()

    async def _get_many(
        self, requests: Iterable[tuple[str, BufferPrototype, ByteRequest | None]]
    ) -> AsyncGenerator[tuple[str, Buffer | None], None]:
        async for req in self._store._get_many(requests):
            yield req
