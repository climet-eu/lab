"""HEALPix functionality."""

import logging

import numpy as np
from cfdm import is_log_level_info

# Import HEALPix functions as a convenience, so that all
# HEALPix-related functions can be imported from this module.
from cf.functions import (  # noqa: F401
    healpix_indexing_schemes,
    healpix_max_refinement_level,
)

logger = logging.getLogger(__name__)


def _healpix_create_latlon_coordinates(f, pole_longitude, cache=True):
    """Create HEALPix latitude and longitude coordinates and bounds.

    When it is not possible to create latitude and longitude
    coordinates, the reason why will be reported if the log level is
    at ``2``/``'INFO'`` or higher.

    See CF Appendix F: Grid Mappings.
    https://doi.org/10.5281/zenodo.14274886

    .. versionadded:: 3.20.0

    :Parameters:

        f: `Field` or `Domain`
            The Field or Domain containing the HEALPix grid, which
            will be updated in-place.

        pole_longitude: `None` or number
            The longitude of HEALPix coordinate bounds that lie
            exactly on the north (south) pole. If `None` then the
            longitude of such a vertex will be the same as the south
            (north) vertex of the same cell. If set to a number, then
            the longitudes of such vertices will all be given that
            value.

        cache: `bool`, optional
            If True (the default) then cache in memory the first and
            last of any newly-created coordinates and bounds. This
            may slightly slow down the coordinate creation process,
            but may greatly speed up, and reduce the memory
            requirement of, a future inspection of the coordinates and
            bounds. Even when *cache* is True, new cached coordinate
            values can only be created if the existing healpix_index
            coordinates themselves have cached first and last values.

    :Returns:

        (`str`, `str`) or (`None`, `None`)
            The keys of the new latitude and longitude coordinate
            constructs, in that order, or two `None`s if the
            coordinates could not be created.

    """
    import dask.array as da

    from .data.dask_utils_healpix import (
        cf_healpix_bounds,
        cf_healpix_coordinates,
    )

    hp = f.healpix_info()

    indexing_scheme = hp.get("indexing_scheme")
    if indexing_scheme not in healpix_indexing_schemes():
        if is_log_level_info(logger):
            logger.info(
                "Can't create 1-d latitude and longitude coordinates for "
                f"{f!r}: indexing_scheme in the healpix grid mapping "
                "coordinate reference must be one of "
                f"{healpix_indexing_schemes()!r}. Got {indexing_scheme!r}"
            )  # pragma: no cover

        return (None, None)

    refinement_level = hp.get("refinement_level")
    if refinement_level is None and indexing_scheme in ("nested", "ring"):
        if is_log_level_info(logger):
            logger.info(
                "Can't create 1-d latitude and longitude coordinates for "
                f"{f!r}: Indexing scheme is {indexing_scheme!r}, but the "
                "refinement_level has not been set in the healpix grid "
                "mapping coordinate reference"
            )  # pragma: no cover

        return (None, None)

    healpix_index = hp.get("healpix_index")
    if healpix_index is None:
        if is_log_level_info(logger):
            logger.info(
                "Can't create 1-d latitude and longitude coordinates for "
                f"{f!r}: Missing healpix_index coordinates"
            )  # pragma: no cover

        return (None, None)

    # Create latitude and longitude cached elements
    if cache:
        cache = healpix_index.data._get_cached_elements()
        cached_lon_coords = {}
        cached_lat_coords = {}
        cached_lon_bounds = {}
        cached_lat_bounds = {}
        for i, value in cache.items():
            if i not in (0, -1):
                continue

            cached_lon_coords[i] = cf_healpix_coordinates(
                value, indexing_scheme, refinement_level, longitude=True
            )
            cached_lat_coords[i] = cf_healpix_coordinates(
                value, indexing_scheme, refinement_level, latitude=True
            )
            cached_lon_bounds[i] = cf_healpix_bounds(
                value,
                indexing_scheme,
                refinement_level,
                longitude=True,
                pole_longitude=pole_longitude,
            )[0, i]
            cached_lat_bounds[i] = cf_healpix_bounds(
                value, indexing_scheme, refinement_level, latitude=True
            )[0, i]

    # Get the Dask array of HEALPix indices.
    #
    # `cf_healpix_coordinates` and `cf_healpix_bounds` have their own
    # calls to `cfdm_to_memory`, so we can set _force_to_memory=False.
    dx = healpix_index.data.to_dask_array(
        _force_mask_hardness=False, _force_to_memory=False
    )
    meta = np.array((), dtype="float64")

    # Create latitude coordinates
    dy = dx.map_blocks(
        cf_healpix_coordinates,
        meta=meta,
        indexing_scheme=indexing_scheme,
        refinement_level=refinement_level,
        latitude=True,
    )
    data = f._Data(dy, "degrees_north")
    if cache:
        data._set_cached_elements(cached_lat_coords)

    lat = f._AuxiliaryCoordinate(
        data=data,
        properties={"standard_name": "latitude"},
        copy=False,
    )

    # Create longitude coordinates
    dy = dx.map_blocks(
        cf_healpix_coordinates,
        meta=meta,
        indexing_scheme=indexing_scheme,
        refinement_level=refinement_level,
        longitude=True,
    )
    data = f._Data(dy, "degrees_east")
    if cache:
        data._set_cached_elements(cached_lon_coords)

    lon = f._AuxiliaryCoordinate(
        data=data,
        properties={"standard_name": "longitude"},
        copy=False,
    )

    # Create latitude bounds
    dy = da.blockwise(
        cf_healpix_bounds,
        "ij",
        dx,
        "i",
        new_axes={"j": 4},
        meta=meta,
        indexing_scheme=indexing_scheme,
        refinement_level=refinement_level,
        latitude=True,
    )
    data = f._Data(dy, "degrees_north")
    if cache:
        data._set_cached_elements(cached_lat_bounds)

    bounds = f._Bounds(data=data)
    lat.set_bounds(bounds, copy=False)

    # Create longitude bounds
    dy = da.blockwise(
        cf_healpix_bounds,
        "ij",
        dx,
        "i",
        new_axes={"j": 4},
        meta=meta,
        indexing_scheme=indexing_scheme,
        refinement_level=refinement_level,
        longitude=True,
        pole_longitude=pole_longitude,
    )
    data = f._Data(dy, "degrees_east")
    if cache:
        data._set_cached_elements(cached_lon_bounds)

    bounds = f._Bounds(data=data)
    lon.set_bounds(bounds, copy=False)

    # Set the new latitude and longitude coordinates
    axis = hp["domain_axis_key"]
    lat_key = f.set_construct(lat, axes=axis, copy=False)
    lon_key = f.set_construct(lon, axes=axis, copy=False)

    return lat_key, lon_key


def _healpix_increase_refinement_level(x, ncells, iaxis, quantity):
    """Increase the HEALPix refinement level in-place.

    See CF Appendix F: Grid Mappings.
    https://doi.org/10.5281/zenodo.14274886

    .. versionadded:: 3.20.0

    :Parameters:

        x: construct
            The construct containing data that is to be changed
            in-place.

        ncells: `int`
            The number of cells at the new refinement level which are
            contained in one cell at the original refinement level.

        iaxis: `int`
            The position of the HEALPix axis in the construct's data
            dimensions.

        quantity: `str`
            Whether the data represent intensive or extensive
            quantities, specified with ``'intensive'`` and
            ``'extensive'`` respectively.

    :Returns:

        `None`

    """
    import dask.array as da
    from dask.array.core import normalize_chunks

    # Get any cached data values
    cached = x.data._get_cached_elements().copy()

    # Get the Dask array (e.g. dx.shape is (12, 19, 48))
    dx = x.data.to_dask_array(_force_mask_hardness=False)

    if quantity == "extensive":
        # Divide extensive data by the number of new cells
        dx = dx / ncells
        if cached:
            cached = {i: value / ncells for i, value in cached.items()}

    # Add a new size dimension just after the HEALPix dimension
    # (e.g. dx.shape becomes (12, 19, 48, 1))
    new_axis = iaxis + 1
    dx = da.expand_dims(dx, new_axis)

    # Modify the size of the new dimension to be the number of cells
    # at the new refinement level which are contained in one cell at
    # the original refinement level (e.g. size becomes 16)
    shape = list(dx.shape)
    shape[new_axis] = ncells

    # Work out what the chunks should be for the new dimension
    chunks = list(dx.chunks)
    chunks[new_axis] = "auto"
    chunks = normalize_chunks(chunks, shape, dtype=dx.dtype)

    # Broadcast the data along the new dimension (e.g. dx.shape
    # becomes (12, 19, 48, 16))
    dx = da.broadcast_to(dx, shape, chunks=chunks)

    # Reshape the array so that it has a single, larger HEALPix
    # dimension (e.g. dx.shape becomes (12, 19, 768))
    dx = dx.reshape(
        shape[:iaxis]
        + [shape[iaxis] * shape[new_axis]]
        + shape[new_axis + 1 :]
    )

    x.set_data(dx, copy=False)

    # Set cached data elements
    if cached:
        x.data._set_cached_elements(cached)


def _healpix_increase_refinement_level_indices(
    healpix_index, ncells, refinement_level
):
    """Increase the refinement level of HEALPix indices in-place.

    See CF Appendix F: Grid Mappings.
    https://doi.org/10.5281/zenodo.14274886

    .. versionadded:: 3.20.0

    :Parameters:

        healpix_index: `Coordinate`
            The HEALPix indices to be changed. They must use the
            nested indexing scheme, but this is not checked.

        ncells: `int`
            The number of cells at the new higher refinement level
            which are contained in one cell at the original refinement
            level.

        refinement_level: `int`
            The new higher refinement level.

    :Returns:

        `None`

    """
    import dask.array as da
    from cfdm import integer_dtype
    from dask.array.core import normalize_chunks

    # Get any cached data values
    cached = healpix_index.data._get_cached_elements().copy()

    # Get the Dask array (e.g. dx.shape is (48,))
    dx = healpix_index.data.to_dask_array(_force_mask_hardness=False)

    # Set the data type to allow for the largest possible HEALPix
    # index at the new refinement level
    dtype = integer_dtype(12 * (4**refinement_level) - 1)
    if dx.dtype != dtype:
        dx = dx.astype(dtype)

    # Change each original HEALPix index to the smallest new HEALPix
    # index that the larger cell contains
    dx = dx * ncells

    # Add a new size dimension just after the HEALPix dimension
    # (e.g. dx.shape becomes (48, 1))
    new_axis = 1
    dx = da.expand_dims(dx, new_axis)

    # Modify the size of the new dimension to be the number of cells
    # at the new refinement level which are contained in one cell at
    # the original refinement level (e.g. size becomes 16)
    shape = list(dx.shape)
    shape[new_axis] = ncells

    # Work out what the chunks should be for the new dimension
    chunks = list(dx.chunks)
    chunks[new_axis] = "auto"
    chunks = normalize_chunks(chunks, shape, dtype=dx.dtype)

    # Broadcast the data along the new dimension (e.g. dx.shape
    # becomes (48, 16))
    dx = da.broadcast_to(dx, shape, chunks=chunks)

    # Increment the broadcast values along the new dimension, so that
    # dx[i, :] contains all of the nested indices at the higher
    # refinement level that correspond to HEALPix index value i at the
    # original refinement level.
    new_shape = [1] * dx.ndim
    new_shape[new_axis] = shape[new_axis]

    dx += da.arange(ncells, chunks=chunks[new_axis]).reshape(new_shape)

    # Reshape the new array to combine the original HEALPix and
    # broadcast dimensions into a single new HEALPix dimension
    # (e.g. dx.shape becomes (768,))
    dx = dx.reshape(shape[0] * shape[new_axis])

    healpix_index.set_data(dx, copy=False)

    # Set new cached data elements
    data = healpix_index.data
    if 0 in cached:
        x = np.array(cached[0], dtype=dtype) * ncells
        data._set_cached_elements({0: x, 1: x + 1})

    if -1 in cached:
        x = np.array(cached[-1], dtype=dtype) * ncells + (ncells - 1)
        data._set_cached_elements({-1: x})


def _healpix_change_indexing_scheme(
    f, hp, new_indexing_scheme, moc_refinement_level=None
):
    """Change the indexing scheme of HEALPix indices in-place.

    The

    See CF Appendix F: Grid Mappings.
    https://doi.org/10.5281/zenodo.14274886

    .. versionadded:: 3.20.0

    :Parameters:

        f: `Field` or `Domain`
            The Field or Domain that contains the healpix_index
            coordinates. *f* will be updated with the new HEALPix
            indices in-place.

        hp: `dict`
            The HEALPix info dictionary for *f*.

        new_indexing_scheme: `str`
            The new indexing scheme. It is assumed to be different to
            the original indexing scheme of *f*.

        moc_refinement_level: `int` or `None`, optional
            The unique refinement level of MOC indices of *f*.

    :Returns:

        `None`

    """
    from cfdm import integer_dtype

    from .data.dask_utils_healpix import cf_healpix_change_indexing_scheme

    healpix_index = hp["healpix_index"]
    indexing_scheme = hp["indexing_scheme"]
    refinement_level = hp.get("refinement_level")

    old_cache = healpix_index.data._get_cached_elements()

    # Find a data type that is sufficient for storing the indices in
    # the new indexing scheme
    if new_indexing_scheme == "nuniq":
        if indexing_scheme in ("nested", "ring"):
            # The largest possible nested or ring index at refinement
            # level N is 12*(4**N) - 1
            dtype = integer_dtype(16 * (4**refinement_level) - 1)
        elif indexing_scheme == "zuniq":
            dtype = np.dtype("int64")

    elif new_indexing_scheme in ("nested", "ring"):
        if indexing_scheme == "nuniq":
            # The largest possible nuniq index at refinement level N
            # is 16*(4**N) - 1 = 4*(4**N) + 12*(4**N) - 1
            dtype = integer_dtype(16 * (4**moc_refinement_level) - 1)
        elif indexing_scheme in ("nested", "ring"):
            dtype = healpix_index.dtype
        elif indexing_scheme == "zuniq":
            dtype = np.dtype("int64")

    elif new_indexing_scheme == "zuniq":
        dtype = np.dtype("int64")

    else:
        raise NotImplementedError(
            "Can't change HEALPix indexing scheme from "
            f"{indexing_scheme!r} to {new_indexing_scheme!r}"
        )  # pragma: no cover

    # Change the HEALPix indices
    #
    # `cf_healpix_change_indexing_scheme` has its own call to
    # `cfdm_to_memory`, so we can set _force_to_memory=False.
    dx = healpix_index.data.to_dask_array(
        _force_mask_hardness=False, _force_to_memory=False
    )

    dx = dx.map_blocks(
        cf_healpix_change_indexing_scheme,
        dtype=dtype,
        meta=np.array((), dtype=dtype),
        indexing_scheme=indexing_scheme,
        new_indexing_scheme=new_indexing_scheme,
        healpix_index_dtype=dtype,
        refinement_level=refinement_level,
        moc_refinement_level=moc_refinement_level,
    )
    healpix_index.set_data(dx, copy=False)

    # If a Dimension Coordinate is now not monotonically ordered,
    # convert it to an Auxiliary Coordinate
    if (
        healpix_index.construct_type == "dimension_coordinate"
        and "ring" in set((indexing_scheme, new_indexing_scheme))
    ):
        f.dimension_to_auxiliary(hp["coordinate_key"], inplace=True)

    # Create new cached elements
    if old_cache and moc_refinement_level is None:
        new_cache = {}
        for i, value in old_cache.items():
            new_cache[i] = cf_healpix_change_indexing_scheme(
                np.array(value),
                indexing_scheme=indexing_scheme,
                new_indexing_scheme=new_indexing_scheme,
                healpix_index_dtype=dtype,
                refinement_level=refinement_level,
                moc_refinement_level=moc_refinement_level,
            )

        healpix_index.data._set_cached_elements(new_cache)


def _healpix_locate(lat, lon, f):
    """Locate HEALPix cells containing latitude-longitude locations.

    Returns the discrete axis indices of the cells containing the
    latitude-longitude locations.

    If a single latitude is given then it is paired with each
    longitude, and if a single longitude is given then it is paired
    with each latitude. If multiple latitudes and multiple longitudes
    are provided then they are paired element-wise.

    If a cell contains more than one of the given latitude-longitude
    locations then that cell's index appears only once in the output.

    See CF Appendix F: Grid Mappings.
    https://doi.org/10.5281/zenodo.14274886

    .. versionadded:: 3.20.0

    .. seealso:: `cf.locate`

    :Parameters:

        lat: (sequence of) number
            The latitude(s), in degrees north, for which to find the
            cell indices. Must be in the range [-90, 90], although
            this is not checked.

        lon: (sequence of) number
            The longitude(s), in degrees east, for which to find the
            cell indices.

        f: `Field` or `Domain`
            The Field or Domain containing the HEALPix grid.

    :Returns:

        `numpy.ndarray`
            Indices for the HEALPix axis that contain the
            latitude-longitude locations. Note that these indices
            identify locations along the HEALPix axis, and are not the
            HEALPix indices defined by the indexing scheme.

    """
    import dask.array as da

    try:
        import healpix
    except ImportError as e:
        raise ImportError(
            f"{e}. Must install healpix (https://pypi.org/project/healpix) "
            "to allow the location of HEALPix cells"
        )

    hp = f.healpix_info()

    healpix_index = hp.get("healpix_index")
    if healpix_index is None:
        raise ValueError(
            f"Can't locate HEALPix cells for {f!r}: There are no "
            "healpix_index coordinates"
        )

    indexing_scheme = hp.get("indexing_scheme")
    match indexing_scheme:
        case "nuniq":
            # nuniq indexing scheme
            index = []
            healpix_index = healpix_index.array
            orders = healpix.uniq2pix(healpix_index, nest=True)[0]
            orders = np.unique(orders)
            for order in orders:
                # For this refinement level, find the HEALPix nested
                # indices of the cells that contain the lat-lon
                # points.
                nside = healpix.order2nside(order)
                pix = healpix.ang2pix(nside, lon, lat, nest=True, lonlat=True)
                # Remove duplicate indices
                pix = np.unique(pix)
                # Convert back to HEALPix nuniq indices
                pix = healpix._chp.nest2uniq(order, pix, pix)
                # Find where these HEALPix indices are located in the
                # healpix_index coordinates
                index.append(da.where(da.isin(healpix_index, pix))[0])

            index = da.unique(da.concatenate(index, axis=0))

        case "nested" | "ring":
            # nested or ring indexing scheme
            refinement_level = hp.get("refinement_level")
            if refinement_level is None:
                raise ValueError(
                    f"Can't locate HEALPix cells for {f!r}: refinement_level "
                    "has not been set in the healpix grid mapping coordinate "
                    "reference"
                )

            # Find the HEALPix indices of the cells that contain the
            # lat-lon points
            nest = indexing_scheme == "nested"
            nside = healpix.order2nside(refinement_level)
            pix = healpix.ang2pix(nside, lon, lat, nest=nest, lonlat=True)
            # Remove duplicate indices
            pix = np.unique(pix)
            # Find where these HEALPix indices are located in the
            # healpix_index coordinates
            index = da.where(da.isin(healpix_index, pix))[0]

        case None:
            raise ValueError(
                f"Can't locate HEALPix cells for {f!r}: indexing_scheme has "
                "not been set in the healpix grid mapping coordinate "
                "reference"
            )

        case _:
            raise ValueError(
                f"Can't locate HEALPix cells for {f!r}: indexing_scheme in "
                "the healpix grid mapping coordinate reference must be one "
                f"of {healpix_indexing_schemes()!r}. Got {indexing_scheme!r}"
            )

    # Return the cell locations as a numpy array of element indices
    return index.compute()


def del_healpix_coordinate_reference(f):
    """Remove a healpix grid mapping coordinate reference construct.

    If required, a new latitude_longitude grid mapping coordinate
    reference will be created in-place to store any generic coordinate
    conversion or datum parameters found in the healpix grid mapping
    coordinate reference.

    .. versionadded:: 3.20.0

    :Parameters:

        f: `Field` or `Domain`
            The Field or Domain from which to delete the healpix grid
            mapping coordinate reference.

    :Returns:

        `CoordinateReference` or `None`
            The removed healpix grid mapping coordinate reference
            construct, or `None` if there wasn't one.

    """
    cr_key, cr = f.coordinate_reference(
        "grid_mapping_name:healpix", item=True, default=(None, None)
    )
    if cr is not None:
        f.del_construct(cr_key)

        latlon = f.coordinate_reference(
            "grid_mapping_name:latitude_longitude", default=None
        )
        if latlon is None:
            latlon = cr.copy()
            cc = latlon.coordinate_conversion
            cc.del_parameter("grid_mapping_name", None)
            cc.del_parameter("indexing_scheme", None)
            cc.del_parameter("refinement_level", None)
            if cc.parameters() or latlon.datum.parameters():
                # The healpix coordinate reference contains generic
                # coordinate conversion or datum parameters
                latlon.coordinate_conversion.set_parameter(
                    "grid_mapping_name", "latitude_longitude"
                )

                # Remove healpix_index coordinates from the coordinate
                # reference
                for key in f.coordinates(
                    "healpix_index", filter_by_naxes=(1,), todict=True
                ):
                    latlon.del_coordinate(key, None)

                f.set_construct(latlon)

    return cr


def healpix_info(f):
    """Get information about the HEALPix grid, if there is one.

    .. versionadded:: 3.20.0

    :Parameters:

        f: `Field` or `Domain`
            The field or domain.

    :Returns:

        `dict`
            The information about the HEALPix axis, with some or all
            of the following dictionary keys:

            * ``'coordinate_reference_key'``: The construct key of the
                                              healpix coordinate
                                              reference construct.

            * ``'grid_mapping_name:healpix'``: The healpix coordinate
                                               reference construct.

            * ``'indexing_scheme'``: The HEALPix indexing scheme.

            * ``'refinement_level'``: The refinement level of the
                                      HEALPix grid.

            * ``'domain_axis_key'``: The construct key of the HEALPix
                                     domain axis construct.

            * ``'coordinate_key'``: The construct key of the
                                    healpix_index coordinate
                                    construct.

            * ``'healpix_index'``: The healpix_index coordinate
                                   construct.

            The dictionary will be empty if there is no HEALPix axis.

    **Examples**

    >>> f = cf.example_field(12)
    >>> healpix_info(f)
    {'coordinate_reference_key': 'coordinatereference0',
     'grid_mapping_name:healpix': <CF CoordinateReference: grid_mapping_name:healpix>,
     'indexing_scheme': 'nested',
     'refinement_level': 1,
     'domain_axis_key': 'domainaxis1',
     'coordinate_key': 'auxiliarycoordinate0',
     'healpix_index': <CF DimensionCoordinate: healpix_index(48)>}

    >>> f = cf.example_field(0)
    >>> healpix_info(f)
    {}

    """
    info = {}

    cr_key, cr = f.coordinate_reference(
        "grid_mapping_name:healpix", item=True, default=(None, None)
    )
    if cr is not None:
        info["coordinate_reference_key"] = cr_key
        info["grid_mapping_name:healpix"] = cr
        parameters = cr.coordinate_conversion.parameters()
        for param in ("indexing_scheme", "refinement_level"):
            value = parameters.get(param)
            if value is not None:
                info[param] = value

    hp_key, healpix_index = f.coordinate(
        "healpix_index",
        filter_by_naxes=(1,),
        item=True,
        default=(None, None),
    )
    if healpix_index is not None:
        info["domain_axis_key"] = f.get_data_axes(hp_key)[0]
        info["coordinate_key"] = hp_key
        info["healpix_index"] = healpix_index

    return info
