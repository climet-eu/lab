#----------------------------------------------------------------
# Generated CMake target import file for configuration "RelWithDebInfo".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "pluto" for configuration "RelWithDebInfo"
set_property(TARGET pluto APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(pluto PROPERTIES
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libpluto.so"
  IMPORTED_SONAME_RELWITHDEBINFO "libpluto.so"
  )

list(APPEND _cmake_import_check_targets pluto )
list(APPEND _cmake_import_check_files_for_pluto "${_IMPORT_PREFIX}/lib/libpluto.so" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
