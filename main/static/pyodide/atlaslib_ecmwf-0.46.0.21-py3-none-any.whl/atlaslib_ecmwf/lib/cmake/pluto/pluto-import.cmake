
include( CMakeFindDependencyMacro )

set( pluto_HAVE_CUDA 0 )
set( pluto_HAVE_HIP  0 )

find_dependency( hic HINTS ${CMAKE_CURRENT_LIST_DIR}/../hic /src/pyodide-recipes/packages/libatlas/build/libatlas-0.46.0/build/hic /src/pyodide-recipes/packages/libatlas/build/libatlas-0.46.0/build/hic )

