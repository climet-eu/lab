#----------------------------------------------------------------
# Generated CMake target import file for configuration "RelWithDebInfo".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "atlas" for configuration "RelWithDebInfo"
set_property(TARGET atlas APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(atlas PROPERTIES
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libatlas.so"
  IMPORTED_SONAME_RELWITHDEBINFO "libatlas.so"
  )

list(APPEND _cmake_import_check_targets atlas )
list(APPEND _cmake_import_check_files_for_atlas "${_IMPORT_PREFIX}/lib/libatlas.so" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
