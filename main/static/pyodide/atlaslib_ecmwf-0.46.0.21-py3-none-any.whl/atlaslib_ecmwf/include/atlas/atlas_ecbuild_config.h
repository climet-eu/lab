/*
 * (C) Copyright 2011- ECMWF.
 *
 * This software is licensed under the terms of the Apache Licence Version 2.0
 * which can be obtained at http://www.apache.org/licenses/LICENSE-2.0.
 * In applying this licence, ECMWF does not waive the privileges and immunities
 * granted to it by virtue of its status as an intergovernmental organisation nor
 * does it submit to any jurisdiction.
 */

#ifndef ATLAS_ecbuild_config_h
#define ATLAS_ecbuild_config_h

/* ecbuild info */

#ifndef ECBUILD_VERSION_STR
#define ECBUILD_VERSION_STR "3.7.0"
#endif
#ifndef ECBUILD_VERSION
#define ECBUILD_VERSION "3.7.0"
#endif
#ifndef ECBUILD_MACROS_DIR
#define ECBUILD_MACROS_DIR  "/src/pyodide-recipes/packages/libatlas/build/libatlas-0.46.0/ecbuild/cmake"
#endif

/* config info */

#define ATLAS_OS_NAME          "Emscripten-1"
#define ATLAS_OS_BITS          32
#define ATLAS_OS_BITS_STR      "32"
#define ATLAS_OS_STR           "UNKNOWN.32"
#define ATLAS_OS_VERSION       "1"
#define ATLAS_SYS_PROCESSOR    "x86"

#define ATLAS_BUILD_TIMESTAMP  "20260907083354"
#define ATLAS_BUILD_TYPE       "RelWithDebInfo"

#define ATLAS_C_COMPILER_ID      "Clang"
#define ATLAS_C_COMPILER_VERSION "23.0.0"

#define ATLAS_CXX_COMPILER_ID      "Clang"
#define ATLAS_CXX_COMPILER_VERSION "23.0.0"

#define ATLAS_C_COMPILER       "/src/emsdk/emsdk/upstream/emscripten/emcc"
#define ATLAS_C_FLAGS          "-fwasm-exceptions -O2 -g0 -fPIC -fwasm-exceptions -sSUPPORT_LONGJMP=wasm -I/src/cpython/installs/python-3.14.2/include/python3.14 -Oz -O2 -g0 -fPIC -fwasm-exceptions -sSUPPORT_LONGJMP=wasm -I/src/cpython/installs/python-3.14.2/include/python3.14 -Oz -O2 -g0 -fPIC -fwasm-exceptions -sSUPPORT_LONGJMP=wasm -I/src/cpython/installs/python-3.14.2/include/python3.14 -Oz -O2 -g0 -fPIC -fwasm-exceptions -sSUPPORT_LONGJMP=wasm -I/src/cpython/installs/python-3.14.2/include/python3.14 -Oz -O2 -g0 -fPIC -fwasm-exceptions -sSUPPORT_LONGJMP=wasm -I/src/cpython/installs/python-3.14.2/include/python3.14 -Oz -pipe -O2 -g -DNDEBUG"

#define ATLAS_CXX_COMPILER     "/src/emsdk/emsdk/upstream/emscripten/em++"
#define ATLAS_CXX_FLAGS        "-fwasm-exceptions -O2 -g0 -fPIC -fwasm-exceptions -sSUPPORT_LONGJMP=wasm -Oz -O2 -g0 -fPIC -fwasm-exceptions -sSUPPORT_LONGJMP=wasm -Oz -O2 -g0 -fPIC -fwasm-exceptions -sSUPPORT_LONGJMP=wasm -Oz -O2 -g0 -fPIC -fwasm-exceptions -sSUPPORT_LONGJMP=wasm -Oz -O2 -g0 -fPIC -fwasm-exceptions -sSUPPORT_LONGJMP=wasm -Oz -pipe -Wall -Wextra -Wno-unused-parameter -Wno-sign-compare -O2 -g -DNDEBUG"

/* Needed for finding per package config files */

#define ATLAS_INSTALL_DIR       "/src/pyodide-recipes/packages/.libs"
#define ATLAS_INSTALL_BIN_DIR   "/src/pyodide-recipes/packages/.libs/bin"
#define ATLAS_INSTALL_LIB_DIR   "/src/pyodide-recipes/packages/.libs/lib"
#define ATLAS_INSTALL_DATA_DIR  "/src/pyodide-recipes/packages/.libs/share/atlas"

#define ATLAS_DEVELOPER_SRC_DIR "/src/pyodide-recipes/packages/libatlas/build/libatlas-0.46.0"
#define ATLAS_DEVELOPER_BIN_DIR "/src/pyodide-recipes/packages/libatlas/build/libatlas-0.46.0/build"

/* Fortran support */

#if 0

#define ATLAS_Fortran_COMPILER_ID      ""
#define ATLAS_Fortran_COMPILER_VERSION ""

#define ATLAS_Fortran_COMPILER ""
#define ATLAS_Fortran_FLAGS    ""

#endif

#endif /* ATLAS_ecbuild_config_h */
