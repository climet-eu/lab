# Copyright 2024-, European Centre for Medium Range Weather Forecasts.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import warnings
from typing import Any

import numpy as np

_UNSET = object()  # Sentinel to distinguish "not passed" from explicit None


class GeometrySource:
    """
    Data source for geometry-based plotting (GeoDataFrames).

    Unlike the coordinate-based Source class, GeometrySource wraps shapely
    geometry objects with associated data values. Used for choropleth maps
    and other geometry-based visualizations.

    Parameters
    ----------
    data : geopandas.GeoDataFrame
        The GeoDataFrame containing geometries and data
    z : str, optional
        Name of the column containing data values for coloring.
        If None, auto-detects first numeric column.
    units : str, optional
        Target units for data values (e.g. ``"celsius"``). See
        :doc:`/examples/examples/introduction/08-unit-conversion` for
        examples.
    metadata : dict, optional
        Additional metadata

    Attributes
    ----------
    geometries : list
        List of shapely geometry objects
    values : np.ndarray or None
        Data values associated with each geometry (for coloring)
    value_name : str
        Name of the data column
    crs : cartopy.crs.CRS or None
        Coordinate reference system
    """

    def __init__(
        self,
        data,
        *,
        z=_UNSET,
        units: str | None = None,
        metadata: dict | None = None,
    ):
        self._check_geopandas(data)
        self._data = data
        self._column = z  # _UNSET = auto-detect, None = use index, str = column name
        self._target_units = units
        self._user_metadata = metadata or {}

        # Lazy evaluation flags
        self._extracted = False
        self._geometries = None
        self._values = None
        self._value_name = None
        self._source_units = None
        self._applied_units = None
        self._value_metadata = {}

    def _check_geopandas(self, data):
        """Verify this is a GeoDataFrame."""
        if data.__class__.__name__ != "GeoDataFrame":
            raise TypeError(f"GeometrySource requires a GeoDataFrame, got {type(data)}")

        if not hasattr(data, "geometry"):
            raise ValueError("GeoDataFrame must have a geometry column")

    def _extract(self):
        """Extract geometries and data values."""
        if self._extracted:
            return

        # Extract geometries
        self._geometries = list(self._data.geometry)

        # Extract data values
        if self._column is _UNSET:
            # z not passed: auto-detect first numeric column
            numeric_cols = self._data.select_dtypes(include=[np.number]).columns
            candidate_cols = [col for col in numeric_cols if col not in ["x", "y", "X", "Y", "geometry"]]
            self._column = candidate_cols[0] if candidate_cols else None

        if self._column is None:
            # z=None explicitly (or no numeric column found): colour by row index
            self._value_name = "index"
            self._values = np.arange(len(self._data), dtype=float)
            self._applied_units = None
            self._extracted = True
            return

        if self._column is not None:
            if self._column not in self._data.columns:
                raise ValueError(f"Column '{self._column}' not found in GeoDataFrame")

            self._value_name = self._column
            self._values = self._data[self._column].values

            # Extract metadata from column if available
            if hasattr(self._data[self._column], "attrs"):
                self._value_metadata = dict(self._data[self._column].attrs)
                self._source_units = self._value_metadata.get("units")

            # User-provided metadata overrides units from column attrs
            if "units" in self._user_metadata:
                self._source_units = self._user_metadata["units"]

            # Apply unit conversion if requested
            if self._target_units is not None and self._values is not None:
                self._values, self._applied_units = self._convert_units(
                    self._values, self._source_units, self._target_units
                )
            else:
                self._applied_units = self._source_units

        self._extracted = True

    def _convert_units(self, values, source_units, target_units):
        """
        Convert data values to target units.

        Returns
        -------
        tuple[np.ndarray, str or None]
            (converted_values, applied_units)
        """
        if source_units is None:
            warnings.warn(
                f"Cannot convert data values to {target_units}: source units not available. Returning original values.",
                UserWarning,
            )
            return values, source_units

        if source_units == target_units:
            return values, target_units

        try:
            from earthkit.plots.metadata import units as metadata_units

            converted = metadata_units.convert(values, source_units, target_units)
            return converted, target_units
        except Exception as e:
            warnings.warn(
                f"Unit conversion failed: {source_units} -> {target_units}. Error: {e}. Returning original values.",
                UserWarning,
            )
            return values, source_units

    @property
    def data(self):
        """Get the underlying GeoDataFrame."""
        return self._data

    @property
    def geometries(self):
        """
        Get list of shapely geometry objects.

        Returns
        -------
        list
            List of shapely geometries (Polygon, Point, LineString, etc.)
        """
        self._extract()
        return self._geometries

    @property
    def values(self):
        """
        Get data values associated with each geometry.

        Returns
        -------
        np.ndarray or None
            Data values (one per geometry), or None if no data column
        """
        self._extract()
        return self._values

    @property
    def value_name(self):
        """
        Get name of the data value column.

        Returns
        -------
        str or None
            Column name, or None if no data
        """
        self._extract()
        return self._value_name

    @property
    def units(self):
        """
        Get units for the data values.

        Returns applied units if conversion occurred, otherwise source units.

        Returns
        -------
        str or None
            Units string or None
        """
        self._extract()
        return self._applied_units

    @property
    def source_units(self):
        """
        Get original source units before conversion.

        Returns
        -------
        str or None
            Original units or None
        """
        self._extract()
        return self._source_units

    @property
    def crs(self):
        """
        Get coordinate reference system.

        Returns
        -------
        cartopy.crs.CRS or None
            The CRS, or None if not available
        """
        if self._data.crs is None:
            return None

        import cartopy.crs as ccrs

        try:
            with warnings.catch_warnings():
                # pyproj always warns when converting to proj4
                warnings.simplefilter("ignore")
                proj4_string = self._data.crs.to_proj4()

            if "longlat" in proj4_string or "latlong" in proj4_string:
                return ccrs.PlateCarree()
            elif "merc" in proj4_string:
                return ccrs.Mercator()
            else:
                return ccrs.CRS(proj4_string)
        except Exception:
            return ccrs.PlateCarree()

    def metadata(self, key: str, default: Any = None) -> Any:
        """
        Get metadata value.

        Checks:
        1. User-provided metadata (from constructor)
        2. GeoDataFrame attrs
        3. Column values (if constant across all rows)
        4. Value-level metadata from column attrs

        Parameters
        ----------
        key : str
            Metadata key
        default : Any
            Default value if not found

        Returns
        -------
        Any
            Metadata value or default
        """
        # Check user metadata first
        if key in self._user_metadata:
            return self._user_metadata[key]

        # Check GeoDataFrame attrs
        if hasattr(self._data, "attrs") and key in self._data.attrs:
            return self._data.attrs[key]

        # Check if key is a column with constant value
        if key in self._data.columns:
            col = self._data[key]
            if col.nunique() == 1:
                return col.iloc[0]

        # Check value-specific metadata
        self._extract()
        if key in self._value_metadata:
            return self._value_metadata[key]

        if key in ["name", "long_name", "standard_name", "variable_name"]:
            if isinstance(self._column, str):
                return self._column

        return default

    def is_vector(self) -> bool:
        """
        Check if this is vector data (u/v components).

        Always False for GeometrySource.

        Returns
        -------
        bool
            False
        """
        return False

    def __repr__(self):
        self._extract()
        n_geoms = len(self._geometries) if self._geometries else 0
        value_str = f", values='{self._value_name}'" if self._value_name else ""
        units_str = f" ({self.units})" if self.units else ""
        return f"GeometrySource({n_geoms} geometries{value_str}{units_str})"
