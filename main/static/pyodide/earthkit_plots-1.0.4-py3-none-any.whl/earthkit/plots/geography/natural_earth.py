# Copyright 2024-, European Centre for Medium Range Weather Forecasts.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import functools
import warnings

import cartopy.io.shapereader as shpreader

from earthkit.plots.geography.bounds import BoundingBox
from earthkit.plots.utils import string_utils

DEFAULT_CAPITAL_CITIES_KWARGS = {
    "marker": "s",
    "s": 25,
    "color": "darkgrey",
    "edgecolor": "grey",
    "linewidths": 0.5,
    "text": {
        "fontsize": 8,
        "fontweight": "bold",
        "color": "black",
    },
}


DEFAULT_MEDIUM_CITIES_KWARGS = {
    "marker": "o",
    "s": 10,
    "color": "grey",
    "edgecolor": "none",
    "linewidths": 0.5,
    "text": {
        "fontsize": 7,
        "color": "black",
    },
}


DEFAULT_SMALL_CITIES_KWARGS = {
    "marker": "o",
    "s": 6,
    "color": "none",
    "edgecolor": "grey",
    "text": {
        "fontsize": 7,
        "fontstyle": "italic",
        "color": "black",
    },
}


RESOLUTIONS = {
    "low": "110m",
    "medium": "50m",
    "high": "10m",
}


def get_resolution(resolution, ax, crs, max_resolution="high", min_resolution="low"):
    resolutions = list(RESOLUTIONS)
    valid_resolutions = resolutions[resolutions.index(min_resolution) : resolutions.index(max_resolution) + 1]
    if resolution is None:
        bbox = BoundingBox(*ax.get_extent(), crs=crs)
        latlon_extents = list(bbox.to_latlon_bbox)
        min_diff = min(
            (latlon_extents[1] - latlon_extents[0]),
            (latlon_extents[3] - latlon_extents[2]),
        )
        if min_diff < 15:
            resolution = "high"
        elif min_diff < 50:
            resolution = "medium"
        else:
            resolution = "low"

    if resolution in RESOLUTIONS:
        if resolutions.index(resolution) < resolutions.index(min_resolution):
            resolution = min_resolution
        elif resolutions.index(resolution) > resolutions.index(max_resolution):
            resolution = max_resolution
        resolution = RESOLUTIONS[resolution]

    if resolution not in RESOLUTIONS.values():
        raise Exception(
            f"urecognised resolution {resolution}; must be one of "
            f"{string_utils.list_to_human(valid_resolutions, conjunction='or')}"
        )
    return resolution


def reproject_geometries(geometries, src_crs, target_crs):
    """
    Reproject a list of shapely geometries from source CRS to target CRS.

    This is used as a performance optimisation to avoid on-the-fly reprojection
    during matplotlib rendering. It's suitable for features with many small
    segments (like coastlines) but not always for features with long straight lines
    that should be curved on the target projection (like political boundaries).

    Parameters
    ----------
    geometries : list
        List of shapely geometries to reproject.
    src_crs : cartopy.crs.CRS
        Source coordinate reference system.
    target_crs : cartopy.crs.CRS
        Target coordinate reference system.

    Returns
    -------
    list
        List of reprojected shapely geometries in target_crs.
    """
    import pyproj
    from shapely.ops import transform

    try:
        # Get proj4 strings for both CRS
        src_proj = getattr(src_crs, "proj4_init", None) or src_crs.proj4_params
        target_proj = getattr(target_crs, "proj4_init", None) or target_crs.proj4_params

        transformer = pyproj.Transformer.from_crs(
            src_proj if isinstance(src_proj, str) else pyproj.CRS.from_proj4(src_proj),
            target_proj if isinstance(target_proj, str) else pyproj.CRS.from_proj4(target_proj),
            always_xy=True,
        )

        reprojected = []
        for geom in geometries:
            try:
                reprojected_geom = transform(transformer.transform, geom)
                if not reprojected_geom.is_empty:
                    reprojected.append(reprojected_geom)
            except Exception as e:
                # If a single geometry fails, warn but continue with others
                warnings.warn(
                    f"Failed to reproject geometry: {e}. Skipping this geometry.",
                    RuntimeWarning,
                )
                continue

        return reprojected

    except Exception as e:
        # If reprojection fails entirely, warn and return original geometries
        warnings.warn(
            f"Geometry reprojection failed: {e}. Falling back to cartopy reprojection.",
            RuntimeWarning,
        )
        return geometries


class NaturalEarthDomain:
    """
    Class for building map domains and CRS based on a Natural Earth shape.

    Parameters
    ----------
    domain_name : str
        The name of the domain to be used.
    crs : cartopy.crs.CRS, optional
        The CRS to be used for the domain. If not provided, the CRS will be
        determined from the shapefile.
    """

    NATURAL_EARTH_SOURCES = {
        "admin_0_map_units": "NAME_LONG",
        "admin_0_countries": "NAME_LONG",
        "admin_1_states_provinces": "name_en",
    }

    def __init__(self, domain_name, crs=None):
        self._domain_name = domain_name
        self._record = None
        self._source = None
        self._crs = crs

    @property
    def domain_name(self):
        return self.record.attributes.get(self.NATURAL_EARTH_SOURCES[self._source])

    @property
    def record(self):
        if self._record is None:
            for source, attribute in self.NATURAL_EARTH_SOURCES.items():
                for record in _load_records("cultural", source, "110m"):
                    name = record.attributes.get(attribute) or ""
                    name = name.replace("\x00", "")
                    if name.lower() == self._domain_name.lower():
                        break
                else:
                    continue
                break
            else:
                raise ValueError(f"No country or state named '{self._domain_name}' found in Natural Earth's shapefiles")
            self._record = record
            self._source = source

        return self._record

    @property
    def geometry(self):
        return self.record.geometry

    @property
    def crs(self):
        if self._crs is None:
            bounds = BoundingBox.from_geometry(self.geometry)
            self._crs = bounds.to_optimised_bbox().crs

        return self._crs

    @property
    def bounds(self, pad=0.1):
        crs_bounds = list(BoundingBox.from_geometry(self.geometry, target_crs=self.crs))

        if pad:
            x_offset = (crs_bounds[1] - crs_bounds[0]) * pad
            y_offset = (crs_bounds[3] - crs_bounds[2]) * pad
            offset = min(x_offset, y_offset)
            crs_bounds = [
                crs_bounds[0] - offset,
                crs_bounds[1] + offset,
                crs_bounds[2] - offset,
                crs_bounds[3] + offset,
            ]

        return crs_bounds


@functools.lru_cache(maxsize=32)
def _load_records(category, name, resolution):
    """Load and cache Natural Earth shapefile records by (category, name, resolution)."""
    shpfilename = shpreader.natural_earth(resolution=resolution, category=category, name=name)
    return list(shpreader.Reader(shpfilename).records())


def load_layer(config, resolution, ax, crs, max_resolution="high", min_resolution="low"):
    """
    Load Natural Earth layer data.

    Parameters
    ----------
    config : dict
        Configuration dictionary with keys: category, name, attribute, label
    resolution : str or None
        Resolution to use (low/medium/high or specific resolution like "10m")
    ax : matplotlib.axes.Axes
        Axes to determine automatic resolution from
    crs : cartopy.crs.CRS
        CRS to determine automatic resolution from
    max_resolution : str
        Maximum resolution to use
    min_resolution : str
        Minimum resolution to use

    Returns
    -------
    tuple
        (records_list, attribute_key, label_key)
    """
    if resolution is None:
        resolution = "medium"  # Default fallback

    resolution = get_resolution(
        resolution,
        ax,
        crs,
        max_resolution,
        min_resolution,
    )

    shape_name = config["name"]
    if isinstance(shape_name, dict):
        shape_name = shape_name[resolution]

    records_list = _load_records(config["category"], shape_name, resolution)

    # Use Natural Earth attribute names from configuration
    attribute_key = config.get("attribute", "NAME_LONG")
    label_key = config.get("label", "NAME_LONG")

    return records_list, attribute_key, label_key
