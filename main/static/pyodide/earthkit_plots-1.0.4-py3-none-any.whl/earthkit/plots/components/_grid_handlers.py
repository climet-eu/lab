# Copyright 2024-, European Centre for Medium Range Weather Forecasts.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""
Grid-type dispatch and coordinate-wrapping helpers for the plotting pipeline.

This module sits between the pipeline orchestration (_pipeline.py) and the
low-level grid renderers (resample/healpix.py, resample/octahedral.py).  It
is responsible for:

- Routing pcolormesh calls for structured/unstructured grids to the correct
  backend (``_handle_specialized_grids``).
- Providing a fast NN pixel-sampling path for regular grids when the source
  and target CRS differ (``_handle_regular_grid_nn``).
- Wrapping coordinates at the antimeridian for global contour plots
  (``_handle_cyclic_points``).
- Resolving ``transform_first="auto"`` from the data/target CRS pair and
  disabling it for projections that do not support it
  (``_handle_transform_settings``).
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

import numpy as np

from earthkit.plots.resample.grids import needs_cyclic_point

if TYPE_CHECKING:
    from earthkit.plots.styles import Style


def _handle_specialized_grids(
    subplot: Any,
    source: Any,
    z_values: np.ndarray,
    style: Style,
    method_name: str,
    kwargs: dict[str, Any],
    resample: Any = None,
    use_nn_sampling: bool = False,
) -> Any | None:
    """
    Route ``pcolormesh`` calls for non-regular grids to the correct backend.

    Returns a matplotlib mappable when it handles the render itself, or
    ``None`` to signal that the caller should proceed with the normal path.

    For ``contourf`` and all other method names this is always a no-op (returns
    ``None``) because those methods do not require special grid handling here.

    Parameters
    ----------
    subplot:
        The target subplot.
    source:
        Data source; provides ``gridspec`` and coordinate arrays.
    z_values:
        Data values to plot.
    style:
        The active style object.
    method_name:
        Name of the plotting method; only ``"pcolormesh"`` is handled here.
    kwargs:
        Live kwargs dict from the caller.
    resample:
        The active resample strategy; used to detect whether a ``Regrid``
        step is present (suppresses the structured-grid error).
    use_nn_sampling:
        When ``True`` (set by ``grid_cells``), activate the nearest-neighbour
        pixel-sampling path.  When ``False``, only validation is performed for
        structured grids.

    Returns
    -------
    mappable or None
    """
    if method_name != "pcolormesh":
        return None

    gridspec = source.gridspec

    # Validate that structured grids are not passed to pcolormesh without a
    # Regrid step.  grid_cells() suppresses this check via use_nn_sampling.
    if gridspec is not None and not use_nn_sampling:
        from earthkit.plots.resample import Chain, _is_structured_grid
        from earthkit.plots.resample import Regrid as _Regrid

        if _is_structured_grid(gridspec):
            _has_regrid = isinstance(resample, _Regrid) or (
                isinstance(resample, Chain) and any(isinstance(s, _Regrid) for s in resample.data_steps)
            )
            if not _has_regrid:
                _grid_label = {
                    "healpix": "HEALPix",
                    "reduced_gg": "reduced Gaussian",
                    "orca": "ORCA",
                }.get(gridspec.name, gridspec.name)
                raise ValueError(
                    f"Input data was identified as a {_grid_label} grid "
                    f"({gridspec.name!r}), which must be regridded onto a regular "
                    "lat/lon grid before it can be visualised with pcolormesh. "
                    "Pass resample=Regrid() (or a Chain that includes Regrid as its "
                    "first data step) to perform the regridding explicitly, or pass "
                    "resample='auto' to let earthkit-plots choose the best approach "
                    "automatically. For all available options see the "
                    "earthkit.plots.resample module documentation. "
                    "Alternatively, use grid_cells() for automatic cell rendering."
                )

    if not use_nn_sampling:
        return None

    # Specialised grid backends (HEALPix, octahedral reduced Gaussian, ORCA).
    if gridspec is not None:
        grid_handlers = {
            "healpix": _plot_healpix,
            "reduced_gg": _plot_octahedral,
            "orca": _plot_orca,
        }
        handler = grid_handlers.get(gridspec.name)
        if handler is not None:
            return handler(subplot, source, z_values, style, kwargs)

    # Fast NN pixel-sampling for regular (non-structured) grids with a CRS mismatch.
    return _handle_regular_grid_nn(subplot, source, z_values, style, kwargs)


def _handle_regular_grid_nn(
    subplot: Any,
    source: Any,
    z_values: np.ndarray,
    style: Style,
    kwargs: dict[str, Any],
) -> Any | None:
    """
    Fast nearest-neighbour pixel-sampling for regular rectilinear grids.

    Activated when the source CRS differs from the target (map) CRS.  For each
    output pixel the centre is back-transformed to the source CRS and the
    nearest source cell is found by ``numpy.searchsorted`` on the 1-D source
    axes — no interpolation, O(nx×ny), crisp cell boundaries.

    Returns a mappable if the fast path was taken, ``None`` if the caller
    should fall through to plain pcolormesh rendering.
    """
    import cartopy.crs as ccrs

    if not hasattr(subplot, "crs") or subplot.crs is None:
        return None

    target_crs = subplot.crs
    data_crs = source.crs or kwargs.get("transform") or ccrs.PlateCarree()

    # Only activate on a genuine CRS mismatch.
    if type(data_crs).__name__ == type(target_crs).__name__:
        return None

    # Only applies to regular rectilinear (meshgrid) sources.
    x_values = source.x.values
    y_values = source.y.values
    if x_values.ndim != 2 or y_values.ndim != 2:
        return None
    if not (np.allclose(x_values, x_values[0, :]) and np.allclose(y_values.T, y_values[:, 0])):
        return None

    x_src_1d = x_values[0, :]
    y_src_1d = y_values[:, 0]

    try:
        bbox_target = subplot.ax.get_extent(crs=target_crs)
    except AttributeError:
        if subplot.domain is not None:
            bbox_target = subplot.domain.bbox.to_cartopy_bounds()
        else:
            bbox_target = (-180, 180, -90, 90)

    from earthkit.plots.resample.reproject import _reproject_nn

    image, extent = _reproject_nn(
        x_src_1d,
        y_src_1d,
        z_values,
        crs_src=data_crs,
        bbox_target=bbox_target,
        crs_target=target_crs,
    )

    plot_kwargs = dict(kwargs)
    if style is not None:
        plot_kwargs.update(style.to_pcolormesh_kwargs(image))
    plot_kwargs.pop("transform", None)
    plot_kwargs.pop("transform_first", None)
    plot_kwargs.setdefault("interpolation", "nearest")

    return subplot.ax.imshow(image, extent=extent, origin="lower", **plot_kwargs)


def _plot_healpix(
    subplot: Any,
    source: Any,
    z_values: np.ndarray,
    style: Style,
    kwargs: dict[str, Any],
) -> Any:
    """Render HEALPix grid data via the nearest-neighbour imshow backend."""
    from earthkit.plots.resample import healpix

    # Determine nest flag from the gridspec (keys: "ordering", "order") or
    # from the earthkit-data legacy metadata key "orderingConvention".
    # Default to ring (nest=False) when ordering is absent or unrecognised.
    gridspec = source.gridspec
    ordering = None
    if gridspec is not None:
        spec_dict = gridspec.to_dict() if hasattr(gridspec, "to_dict") else {}
        ordering = spec_dict.get("ordering") or spec_dict.get("order")
    if ordering is None:
        ordering = source.metadata("orderingConvention", default=None)
    nest = str(ordering).lower() == "nested" if ordering is not None else False
    kwargs["transform"] = subplot.crs
    return healpix.nnshow(z_values, ax=subplot.ax, nest=nest, style=style, **kwargs)


def _plot_octahedral(
    subplot: Any,
    source: Any,
    z_values: np.ndarray,
    style: Style,
    kwargs: dict[str, Any],
) -> Any:
    """Render octahedral reduced Gaussian grid data via the nnshow backend."""
    from earthkit.plots.resample import octahedral

    return octahedral.nnshow(
        source.x.values,
        source.y.values,
        z_values,
        subplot.ax,
        style=style,
        **kwargs,
    )


def _plot_orca(
    subplot: Any,
    source: Any,
    z_values: np.ndarray,
    style: Style,
    kwargs: dict[str, Any],
) -> Any:
    """Render ORCA curvilinear grid data via KD-tree nearest-neighbour imshow."""
    from earthkit.plots.resample import orca

    return orca.nnshow(
        source.x.values,
        source.y.values,
        z_values,
        subplot.ax,
        style=style,
        **kwargs,
    )


def _add_pcolormesh_wrap_column(
    x_values: np.ndarray,
    y_values: np.ndarray,
    z_values: np.ndarray,
) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    """
    Append a closing longitude column at 180° for pcolormesh after 0–360 →
    –180..+180 normalisation, so the last cell renders fully.

    ``pcolormesh`` infers cell edges as midpoints between adjacent centres.
    For a global grid with centres at –180..+150 (step 30°) the inferred
    right edge of the last cell is 165°, not 180° — the east half is blank.

    Appending a duplicate z-column and setting the closing longitude to 180°
    gives pcolormesh a right-neighbour at 180° so it infers the edge of the
    original last cell at 165° and of the new closing cell from 165° onward.
    The closing cell is a duplicate of the first (wrap-around) cell, which is
    the correct value at the antimeridian for global data.

    Only applied when x_max + step ≈ 180° (data was originally global 0–360
    and the last cell wraps at the antimeridian).

    x_values may be 1-D (earthkit path) or 2-D meshgrid.
    z_values is always 2-D (ny, nx).
    """
    x_1d = x_values[0] if x_values.ndim == 2 else x_values

    x_step = np.abs(np.median(np.diff(x_1d)))
    x_max = x_1d.max()

    # Only activate when the last centre is exactly one step below 180°.
    if not np.isclose(x_max + x_step, 180.0, atol=x_step * 0.1):
        return x_values, y_values, z_values

    # Append a closing column so pcolormesh has a right-neighbour at 180°.
    z_values = np.concatenate([z_values, z_values[:, :1]], axis=1)

    if x_values.ndim == 2:
        ny = x_values.shape[0]
        x_values = np.concatenate([x_values, np.full((ny, 1), 180.0)], axis=1)
        y_values = np.concatenate([y_values, y_values[:, :1]], axis=1)
    else:
        x_values = np.append(x_values, 180.0)

    return x_values, y_values, z_values


def _handle_cyclic_points(
    x_values: np.ndarray,
    y_values: np.ndarray,
    z_values: np.ndarray,
) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    """
    Add a cyclic longitude column to ensure global contour plots wrap correctly.

    When the data spans the full longitude range but is missing the closing
    column at 360°/−180°, contourf leaves a gap at the antimeridian.
    ``cartopy.util.add_cyclic_point`` inserts the missing column.

    This is a no-op when the data does not need a cyclic point.
    """
    if not needs_cyclic_point(x_values):
        return x_values, y_values, z_values

    # add_cyclic_point expects 1-D longitude; extract from a 2-D meshgrid if needed.
    n_x = None
    if x_values.ndim != 1:
        n_x = x_values.shape[0]
        x_values = x_values[0]

    from cartopy.util import add_cyclic_point

    z_values, x_values = add_cyclic_point(z_values, coord=x_values)

    # Restore 2-D meshgrid structure.
    if n_x is not None:
        x_values = np.tile(x_values, (n_x, 1))
        y_values = np.hstack((y_values, y_values[:, -1][:, np.newaxis]))

    return x_values, y_values, z_values


def _handle_transform_settings(
    subplot: Any,
    kwargs: dict[str, Any],
) -> dict[str, Any]:
    """
    Resolve ``transform_first="auto"`` and disable it where unsupported.

    ``transform_first`` trades off two very different cartopy code paths:

    * ``True`` pre-projects the raw grid points in one vectorised
      ``transform_points`` call and contours in projected space — fast, but
      on *curved* (non-cylindrical) target projections a fine lat/lon mesh
      collapses into vertical-sliver artifacts.
    * ``False`` contours in data space and then transforms each contour
      polygon through the projection — always correct, but per-path,
      per-vertex work that is very slow for dense grids with many levels.

    Neither is a safe global default, so the schema ships ``"auto"`` and this
    function resolves it per-plot from the data/target CRS pair:

    * **Equal CRS** (``crs_equal``): rewrite ``kwargs["transform"]`` to the
      axes' own CRS object so cartopy's ``transform == self.projection``
      short-circuit fires and no reprojection happens at all.  Separately
      constructed but equivalent CRS objects can fail cartopy's ``==`` (e.g.
      a domain-optimised PlateCarree without ``+datum``), which would
      otherwise force the slow path even though no transform is needed.
    * **Cylindrical → cylindrical**: ``True`` — point pre-projection is
      numerically benign (essentially a longitude shift) and much faster.
    * **Anything → curved projection**: ``False`` — correctness first; the
      default resample path (``Chain(Regrid(), Bilinear)``) already avoids
      the cost by reprojecting onto the target grid before rendering.

    Explicit user values (``True``/``False``) are passed through untouched.
    Finally, projections in ``CANNOT_TRANSFORM_FIRST`` (where cartopy raises
    at render time) force the flag to ``False`` regardless of the above.
    """
    if "transform_first" not in kwargs:
        return kwargs

    from earthkit.plots.geography import coordinate_reference_systems

    target_crs = subplot.crs

    if kwargs["transform_first"] == "auto":
        data_crs = kwargs.get("transform")
        if target_crs is None or data_crs is None:
            # Non-geographic axes or no data transform: nothing to pre-project,
            # and plain matplotlib axes do not accept the kwarg at all.
            kwargs.pop("transform_first")
            return kwargs
        if coordinate_reference_systems.crs_equal(data_crs, target_crs):
            kwargs["transform"] = target_crs
            kwargs["transform_first"] = False
        elif coordinate_reference_systems.is_cylindrical(data_crs) and coordinate_reference_systems.is_cylindrical(
            target_crs
        ):
            kwargs["transform_first"] = True
        else:
            kwargs["transform_first"] = False

    if target_crs.__class__ in coordinate_reference_systems.CANNOT_TRANSFORM_FIRST:
        kwargs["transform_first"] = False
    return kwargs
