# Copyright 2024-, European Centre for Medium Range Weather Forecasts.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import datetime
import logging
import re
from string import Formatter
from zoneinfo import ZoneInfo

import dateutil
import numpy as np

from earthkit.plots import metadata
from earthkit.plots.schemas import schema
from earthkit.plots.sources.dimensions import DimensionInfo
from earthkit.plots.utils import iter_utils, string_utils

logger = logging.getLogger(__name__)

# Matches an optional standard fill/align/width/precision prefix followed by a
# timedelta unit letter.  Examples: "h", "03h", ".1h", ">5d", "D", "H", "M".
_TIMEDELTA_SPEC_RE = re.compile(r"^(?P<std_prefix>[^a-zA-Z]*)(?P<unit>[dhmsHDMS])$")

_SINGLE_UNITS = {"d": 86400, "h": 3600, "m": 60, "s": 1}
_COMPOUND_UNITS = {
    # spec letter -> (units to emit, in descending order)
    "D": ("d", "h", "m", "s"),
    "H": ("h", "m", "s"),
    "M": ("m", "s"),
}
_ALL_TIMEDELTA_UNITS = set(_SINGLE_UNITS) | set(_COMPOUND_UNITS)


def _coerce_to_timedelta(value):
    """Return a timedelta from an int (hours), float (hours), or timedelta."""
    if isinstance(value, datetime.timedelta):
        return value
    if isinstance(value, (int, float)):
        return datetime.timedelta(hours=value)
    raise TypeError(f"Cannot convert {type(value).__name__!r} to timedelta")


def format_timedelta(value, spec):
    """Format a timedelta using earthkit-plots timedelta specs.

    Single-unit lowercase (d/h/m/s): total in that unit, truncated toward zero
    (or formatted with the given precision if the prefix includes one).
    Compound uppercase (D/H/M): largest named unit descending, zero components
    omitted. Compound specs do not accept a fill/align/width prefix.
    """
    match = _TIMEDELTA_SPEC_RE.match(spec)
    unit = match.group("unit") if match else None
    if unit not in _ALL_TIMEDELTA_UNITS:
        raise ValueError(f"Invalid timedelta format spec {spec!r}. Valid unit codes: {sorted(_ALL_TIMEDELTA_UNITS)}")
    prefix = match.group("std_prefix")

    total_seconds = _coerce_to_timedelta(value).total_seconds()
    sign = "-" if total_seconds < 0 else ""
    total_seconds = abs(total_seconds)

    if unit in _SINGLE_UNITS:
        amount = total_seconds / _SINGLE_UNITS[unit]
        # If the prefix specifies precision (".1f"-style), format as float;
        # otherwise truncate toward zero and let the prefix handle width/fill.
        if "." in prefix:
            body = format(amount, prefix + "f")
        else:
            body = format(int(amount), prefix) if prefix else str(int(amount))
        return sign + body

    if prefix:
        raise ValueError(f"Fill/align/width prefix {prefix!r} is not supported for compound timedelta spec {spec!r}")

    # Compound: walk units largest-to-smallest, taking the integer quotient
    # and carrying the remainder forward.
    remaining = int(total_seconds)
    parts = []
    for u in _COMPOUND_UNITS[unit]:
        qty, remaining = divmod(remaining, _SINGLE_UNITS[u])
        if qty:
            parts.append(f"{qty}{u}")
    body = " ".join(parts) if parts else f"0{_COMPOUND_UNITS[unit][0]}"
    return sign + body


def parse_time(time):
    return [dateutil.parser.parse(str(t)) for t in time]


SPECIAL_METHODS = {
    "parse_time": parse_time,
}


class BaseFormatter(Formatter):
    """
    Base formatter class for earthkit-plots metadata.

    This class provides basic formatting capabilities for metadata values,
    including support for coordinate formatting with degree symbols and directions.

    Format Specifiers:
    - %Lt: Format as latitude with degree symbol and N/S direction
           Example: 45.0 -> "45.00°N", -30.5 -> "30.50°S"
    - %Lt.1f: Format as latitude with custom precision (1 decimal place)
           Example: 45.0 -> "45.0°N", -30.5 -> "30.5°S"
    - %Ln: Format as longitude with degree symbol and E/W direction
           Example: 15.2 -> "15.20°E", -45.8 -> "45.80°W"
    - %Ln.1f: Format as longitude with custom precision (1 decimal place)
           Example: 15.2 -> "15.2°E", -45.8 -> "45.8°W"
    - %c: Format location as city name only
           Example: LocationInfo(city="London", country="United Kingdom") -> "London"
    - %C: Format location as country name only
           Example: LocationInfo(city="London", country="United Kingdom") -> "United Kingdom"
    - __units__: Format units using the metadata.units module
    """

    #: Attributes of subplots which can be extracted by format strings
    SUBPLOT_ATTRIBUTES = {
        "domain": "domain_name",
        "crs": "crs_name",
    }

    #: Attributes of styles which can be extracted by format strings
    STYLE_ATTRIBUTES = {
        "units": "units",
    }

    def convert_field(self, value, conversion):
        """
        Convert a field value according to the conversion type.

        Parameters
        ----------
        value : object
            The value to be converted.
        conversion : str
            The conversion type.
        """
        if conversion == "u":
            return str(value).upper()
        elif conversion == "l":
            return str(value).lower()
        elif conversion == "c":
            return str(value).capitalize()
        elif conversion == "t":
            return str(value).title()
        return super().convert_field(value, conversion)

    def format_keys(self, format_string, kwargs):
        """
        Format keys in a format string.

        Parameters
        ----------
        format_string : str
            The format string.
        kwargs : dict
            The keyword arguments to be formatted.
        """
        keys = (i[1] for i in self.parse(format_string) if i[1] is not None)
        for key in keys:
            main_key, *methods = key.split(".")
            # If the key contains dots, first try resolving the full dotted key
            # as a single metadata lookup (e.g. "time.valid_datetime" from
            # earthkit-data's namespaced metadata API).  Only fall back to the
            # chained-method path (x.units, y.variable_name, …) when the full
            # key produces nothing useful.
            if methods:
                full_result = self.format_key(key)
                resolved = full_result[0] if isinstance(full_result, list) and len(full_result) == 1 else full_result
                if resolved is not None and not isinstance(resolved, DimensionInfo):
                    kwargs[key] = full_result
                    continue
            result = self.format_key(main_key)
            for method in methods:
                if method in SPECIAL_METHODS:
                    result = SPECIAL_METHODS[method](result)
                # Check if result is a DimensionInfo object
                elif len(result) == 1 and isinstance(result[0], DimensionInfo):
                    dim_info = result[0]
                    # Handle DimensionInfo attribute/method access
                    if method == "metadata":
                        # For metadata, we need to handle it specially in MAGIC_KEYS
                        # For now, just access as attribute - will be handled later
                        result = [None]
                    elif hasattr(dim_info, method):
                        attr_value = getattr(dim_info, method)
                        # If it's a callable (like metadata()), we can't call it without args
                        # Otherwise, get the attribute value
                        result = [attr_value]
                    elif method in metadata.labels.MAGIC_KEYS:
                        # Handle magic keys by calling metadata() on the dimension
                        # Get the preference list for this magic key
                        candidates = metadata.labels.MAGIC_KEYS[method].get("preference", [method])
                        value = None
                        for candidate in candidates:
                            value = dim_info.metadata(candidate)
                            if value is not None:
                                break
                        # Apply transformations
                        if value is not None and metadata.labels.MAGIC_KEYS[method].get("remove_underscores"):
                            if isinstance(value, str):
                                value = value.replace("_", " ")
                        result = [value]
                    else:
                        # Try as a regular metadata key
                        value = dim_info.metadata(method)
                        result = [value]
                else:
                    # Not a DimensionInfo - try numpy method
                    result = getattr(np, method)(result)
                if not isinstance(result, (list, tuple, np.ndarray)):
                    result = [result]
            kwargs[key] = result
        return kwargs

    def format_key(self, key):
        return key

    def format(self, format_string, /, *args, **kwargs):
        kwargs = self.format_keys(format_string, kwargs)
        keys = list(kwargs)
        for key in keys:
            if "." in key:
                replacement_key = key.replace(".", "_")
                kwargs[replacement_key] = kwargs.pop(key)
                format_string = format_string.replace(key, replacement_key)
        return super().format(format_string, *args, **kwargs)

    def format_field(self, value, format_spec):
        """
        Format a field value according to the format specification.

        Parameters
        ----------
        value : object
            The value to be formatted.
        format_spec : str
            The format specification.
        """
        if value is None:
            return ""

        # format_keys stores results as lists; unwrap single-element lists so
        # that format specs (e.g. {time:%H}) operate on the value itself.
        if isinstance(value, list) and len(value) == 1:
            value = value[0]

        if isinstance(value, str) and value.startswith("__units__"):
            return metadata.units.format_units(value.replace("__units__", ""), format_spec)

        # Pass datetime-like objects directly when format_spec contains strftime patterns
        if isinstance(value, np.datetime64) and "%" in format_spec:
            import pandas as pd

            value = pd.Timestamp(value)
        if isinstance(value, np.integer):
            value = int(value)
        if isinstance(value, (datetime.datetime, datetime.date)) and "%" in format_spec:
            return format(value, format_spec)

        # Timedelta format specs (e.g. h, d, D, H, 03h, .1h).
        # With no spec, default to the compound "H" format (e.g. "3 days 6 hours").
        if isinstance(value, (int, float, datetime.timedelta)):
            if not format_spec:
                return format_timedelta(value, "h")
            td_match = _TIMEDELTA_SPEC_RE.match(format_spec)
            if td_match and td_match.group("unit") in _ALL_TIMEDELTA_UNITS:
                return format_timedelta(value, format_spec)

        # Handle coordinate format specifiers
        if format_spec.startswith("%Lt"):
            # Format as latitude with degree symbol and N/S direction
            precision = self._extract_precision(format_spec, default=2)
            return self._format_latitude(value, precision)
        elif format_spec.startswith("%Ln"):
            # Format as longitude with degree symbol and E/W direction
            precision = self._extract_precision(format_spec, default=2)
            return self._format_longitude(value, precision)
        elif format_spec == "%c":
            # Format location as city
            return self._format_location_city(value)
        elif format_spec == "%C":
            # Format location as country
            return self._format_location_country(value)

        return super().format_field(value, format_spec)

    def _extract_precision(self, format_spec, default=2):
        """Extract precision from format specification like %Lt.1f or %Ln.3f."""
        import re

        # Match patterns like %Lt.1f, %Ln.3f, etc.
        match = re.match(r"%L[tn]\.(\d+)f?", format_spec)
        if match:
            return int(match.group(1))
        return default

    def _format_latitude(self, value, precision=2):
        """Format a latitude value with degree symbol and N/S direction."""
        try:
            lat = float(value)
            direction = "N" if lat >= 0 else "S" if lat < 0 else ""
            abs_lat = abs(lat)
            return f"{abs_lat:.{precision}f}°{direction}"
        except (ValueError, TypeError):
            return str(value)

    def _format_longitude(self, value, precision=2):
        """Format a longitude value with degree symbol and E/W direction."""
        try:
            lon = float(value)
            direction = "E" if lon >= 0 else "W"
            abs_lon = abs(lon)
            return f"{abs_lon:.{precision}f}°{direction}"
        except (ValueError, TypeError):
            return str(value)

    def _format_location_city(self, value):
        """Format a location value to show only the city."""
        # Import here to avoid circular imports
        from earthkit.plots.metadata.labels import LocationInfo

        if isinstance(value, LocationInfo):
            return value.city or str(value)
        else:
            return str(value)

    def _format_location_country(self, value):
        """Format a location value to show only the country."""
        # Import here to avoid circular imports
        from earthkit.plots.metadata.labels import LocationInfo

        if isinstance(value, LocationInfo):
            return value.country or str(value)
        else:
            return str(value)


class SourceFormatter(BaseFormatter):
    """
    Formatter of earthkit-plots `Layers`, enabling convenient titles and labels.

    Supports dimension access like {x.units}, {y.variable_name}, {z.units}.
    """

    def __init__(self, source, axis=None):
        self.source = source
        self._axis = axis

    def format_key(self, key):
        # Check if key is a dimension access (x, y, or z)
        if key in ("x", "y", "z") and hasattr(self.source, key):
            # Return the DimensionInfo object so subsequent method calls work
            dim = getattr(self.source, key)
            if dim is not None:
                return [dim]
            # If dimension is None (e.g., z for 1D plots), fall through to regular extraction

        result = metadata.labels.extract(self.source, key, axis=self._axis)
        if isinstance(result, (list, tuple)):
            result = result[0]

        if key == "units" and isinstance(result, str):
            return [f"__units__{result}"]
        return [result]


class LayerFormatter(BaseFormatter):
    """Formatter of earthkit-plots `Layers`, enabling convient titles and labels."""

    def __init__(self, layer, default=None, issue_warnings=True, axis=None):
        self.layer = layer
        self._default = default
        self._issue_warnings = issue_warnings
        self._axis = axis

    def format_key(self, key):
        # Check if key is a dimension access (x, y, or z)
        if key in ("x", "y", "z"):
            # Return DimensionInfo objects from sources
            dim_values = []
            for source in self.layer.sources:
                if hasattr(source, key):
                    dim = getattr(source, key)
                    if dim is not None:
                        dim_values.append(dim)

            # If we got DimensionInfo objects, set as value and fall through to unwrapping
            if dim_values:
                value = dim_values
                # Skip to unwrapping logic at the end
                # (don't execute the normal extraction path)
            else:
                # No DimensionInfo found for this dimension key, fall through to normal extraction
                value = None
        else:
            # Not a dimension key, initialize value for normal extraction
            value = None

        # Normal extraction path (only executed if value is None)
        if value is None:
            if key in self.SUBPLOT_ATTRIBUTES:
                value = getattr(self.layer.subplot, self.SUBPLOT_ATTRIBUTES[key])
            elif key == "units":
                # Priority order:
                # 1. axis_units (set by fix_x/y_units or per-call units=)
                # 2. style.units (explicitly set by the user on the Style object)
                # 3. source.units (applied/converted units from the data source)
                # 4. raw metadata extraction from source
                axis_specific_units = (
                    self.layer.axis_units.get(self._axis)
                    if hasattr(self.layer, "axis_units") and self._axis is not None
                    else None
                )
                style_units = getattr(self.layer.style, "units", None) if self.layer.style is not None else None
                if axis_specific_units is not None:
                    value = [f"__units__{axis_specific_units}"]
                elif style_units:
                    value = [f"__units__{style_units}"]
                else:
                    value = [
                        f"__units__{source.units}"
                        if source.units
                        else metadata.labels.extract(
                            source,
                            key,
                            default=self._default,
                            issue_warnings=self._issue_warnings,
                            axis=self._axis,
                        )
                        for source in self.layer.sources
                    ]
            elif key in self.STYLE_ATTRIBUTES and self.layer.style is not None:
                value = getattr(self.layer.style, self.STYLE_ATTRIBUTES[key])
                if value is None:
                    value = [
                        metadata.labels.extract(
                            source,
                            key,
                            default=self._default,
                            issue_warnings=self._issue_warnings,
                            axis=self._axis,
                        )
                        for source in self.layer.sources
                    ]
            else:
                value = [
                    metadata.labels.extract(
                        source,
                        key,
                        default=self._default,
                        issue_warnings=self._issue_warnings,
                        axis=self._axis,
                    )
                    for source in self.layer.sources
                ]

        # Unwrapping logic for all paths
        if isinstance(value, list):
            if len(value) == 1 or iter_utils.all_equal(value):
                value = value[0]
            else:
                value = string_utils.list_to_human(value)
        return value

    def format_field(self, _value, format_spec):
        # Handle list values from single sources (e.g., vector fields returning ["wind U", "wind V"])
        if isinstance(_value, list):
            # Apply format_spec to each element
            formatted_values = [super().format_field(v, format_spec) for v in _value]
            # Get unique values
            unique_values = list(dict.fromkeys(formatted_values))
            # If all values are the same, return just one
            if len(unique_values) == 1:
                return unique_values[0]
            # Otherwise format as human-readable list
            return string_utils.list_to_human(unique_values)

        return super().format_field(_value, format_spec)


class SubplotFormatter(BaseFormatter):
    """Formatter of earthkit-plots `Subplots`, enabling convient titles and labels."""

    def __init__(self, subplot, unique=True, axis=None):
        self.subplot = subplot
        self.unique = unique
        self._layer_index = None
        self._axis = axis

    def convert_field(self, value, conversion):
        f = super().convert_field
        if isinstance(value, list):
            if isinstance(conversion, str) and conversion.isnumeric():
                try:
                    return str(value[int(conversion)])
                except IndexError as err:
                    error_message = (
                        f"Layer index {conversion} in title is out of range. "
                        f"This subplot contains {len(value)} layer{'s' if len(value) != 1 else ''}."
                    )
                    raise IndexError(error_message) from err
            return [f(v, conversion) for v in value]
        else:
            return f(value, conversion)

    def format_key(self, key):

        from earthkit.plots.metadata.labels import LocationInfo

        if key in self.SUBPLOT_ATTRIBUTES:
            values = [getattr(self.subplot, self.SUBPLOT_ATTRIBUTES[key])]
        else:
            # Collect values without per-layer warnings; warn once only if no
            # layer carries the key at all.
            values = [
                LayerFormatter(layer, axis=self._axis, issue_warnings=False).format_key(key)
                for layer in self.subplot.layers
            ]
            if all(v is None for v in values):
                # For location, fall back to a single "Unknown location" sentinel
                # rather than warning — missing geographic metadata is expected.
                if key == "location":
                    values = [LocationInfo()]
        return values

    def format_field(self, value, format_spec):
        f = super().format_field
        if isinstance(value, list):
            values = [f(v, format_spec) for v in value]
            if self._layer_index is not None:
                value = values[self._layer_index]
                self._layer_index = None
            else:
                # Drop empty strings that arose from None values before
                # deduplication so they don't pollute the rendered title.
                values = [v for v in values if v != ""]
                if self.unique:
                    values = list(dict.fromkeys(values))
                value = string_utils.list_to_human(values)
        else:
            value = f(value, format_spec)
        return value


class FigureFormatter(BaseFormatter):
    """Formatter of earthkit-plots `Charts`, enabling convient titles and labels."""

    def __init__(self, subplots, unique=True):
        self.subplots = subplots
        self.unique = unique
        self._layer_index = None

    def convert_field(self, value, conversion):
        f = super().convert_field
        if isinstance(value, list):
            if isinstance(conversion, str) and conversion.isnumeric():
                return str(value[int(conversion)])
            return [f(v, conversion) for v in value]
        else:
            return f(value, conversion)

    def format_key(self, key):
        values = [SubplotFormatter(subplot).format_key(key) for subplot in self.subplots]
        values = [item for sublist in values for item in sublist]
        return values

    def format_field(self, value, format_spec):
        f = super().format_field
        if isinstance(value, list):
            values = [f(v, format_spec) for v in value]
            if self._layer_index is not None:
                value = values[self._layer_index]
                self._layer_index = None
            else:
                # Drop empty strings that arose from None values before
                # deduplication so they don't pollute the rendered title.
                values = [v for v in values if v != ""]
                if self.unique:
                    values = list(dict.fromkeys(values))
                value = string_utils.list_to_human(values)
        else:
            value = f(value, format_spec)
        return value


class TimeFormatter:
    """
    Formatter of time data, enabling convient time labels.

    Parameters
    ----------
    times : list
        The times to be formatted.
    time_zone : str, optional
        The time zone to be used for the times.
    """

    def __init__(self, times, time_zone=None):
        # Accept a Source (or any object with a .datetime() method) directly.
        if hasattr(times, "datetime") and callable(times.datetime):
            times = times.datetime()
        if not isinstance(times, (list, tuple)):
            times = [times]
        for i, time in enumerate(times):
            if not isinstance(time, dict):
                times[i] = {"time": time}
        self.times = times
        time_zone = time_zone or schema.time_zone
        self._time_zone = time_zone if time_zone is None else ZoneInfo(time_zone)

    def _extract_time(method):
        def wrapper(self):
            attr = method.__name__
            times = [self._named_time(time, attr) for time in self.times]
            if len(np.array(times).shape) > 1 and np.array(times).shape[0] == 1:
                times = times[0]
            _, indices = np.unique(times, return_index=True)
            result = [times[i] for i in sorted(indices)]
            if self._time_zone is not None:
                if None in [t.tzinfo for t in result]:
                    logger.warning(
                        "Attempting time zone conversion, but some data has no time zone metadata; assuming UTC"
                    )
                    result = [t if t.tzinfo is not None else t.replace(tzinfo=ZoneInfo("UTC")) for t in result]
                result = [t.astimezone(tz=self._time_zone) for t in result]
            return result

        return property(wrapper)

    # Maps canonical TimeFormatter attribute names to the keys that may appear
    # in the time dict, in priority order.
    _KEY_ALIASES = {
        "valid_time": ["valid_time", "time.valid_datetime", "time"],
        "base_time": ["base_time", "time.base_datetime"],
        "lead_time": ["lead_time", "time.step"],
    }

    @staticmethod
    def _named_time(time, attr):
        for key in TimeFormatter._KEY_ALIASES.get(attr, [attr, "time"]):
            value = time.get(key)
            if value is not None:
                return value
        return time.get("time")

    @property
    def time(self):
        """The most basic representation of time."""
        return self.valid_time

    @property
    def utc_offset(self):
        """The offset in hours from UTC."""
        valid_times = self.valid_time
        if None in [vt.tzinfo for vt in valid_times]:
            logger.warning("Some of the data is missing time zone metadata; assuming UTC")
            valid_times = [t if t.tzinfo is not None else t.replace(tzinfo=ZoneInfo("UTC")) for t in valid_times]
        offsets = [vt.utcoffset().seconds // 3600 for vt in valid_times]
        time_zones = [f"UTC{offset:+d}" for offset in offsets]
        return time_zones

    @_extract_time
    def base_time(self):
        """The base time of the data, i.e. the time of the forecast."""
        pass

    @_extract_time
    def valid_time(self):
        """The valid time of the data, i.e. the time the forecast is for."""
        pass

    @property
    def lead_time(self):
        """The lead time of the data, i.e. the time between the base and valid times."""
        lead_times = []
        for time in self.times:
            # Prefer an explicit step/lead_time value.
            step = time.get("lead_time") or time.get("time.step")
            if step is not None:
                lead_times.append(_coerce_to_timedelta(step))
                continue
            btime = self._named_time(time, "base_time")
            vtime = self._named_time(time, "valid_time")
            if isinstance(btime, (list, tuple)):
                btime = btime[0]
            if isinstance(vtime, (list, tuple)):
                vtime = vtime[0]
            if btime is not None and vtime is not None:
                lead_times.append(vtime - btime)
            else:
                lead_times.append(None)

        if len(lead_times) > 1:
            non_none_values = [x for x in lead_times if x is not None]
            if non_none_values:
                result = []
                seen_values = set()
                for value in lead_times:
                    if value is None:
                        result.append(None)
                    elif value not in seen_values:
                        result.append(value)
                        seen_values.add(value)
            else:
                result = lead_times
        else:
            result = lead_times

        return result


def format_month(data):
    """
    Extract the month of the data time.

    Parameters
    ----------
    data : earthkit.maps.sources.Source
        The data source.
    """
    import calendar

    month = data.metadata("month", default=None)
    if month is not None:
        month = calendar.month_name[month]
    else:
        dt_info = data.datetime()
        time = dt_info.get("valid_time") or dt_info.get("base_time")
        month = f"{time:%B}" if time is not None else None
    return month
