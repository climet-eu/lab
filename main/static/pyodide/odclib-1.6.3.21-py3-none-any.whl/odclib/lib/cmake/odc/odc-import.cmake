include( CMakeFindDependencyMacro )

find_dependency( eckit HINTS ${CMAKE_CURRENT_LIST_DIR}/../eckit /src/pyodide-recipes/packages/.libs/lib/cmake/eckit )
