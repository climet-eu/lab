/*
 * (C) Copyright 2011- ECMWF.
 *
 * This software is licensed under the terms of the Apache Licence Version 2.0
 * which can be obtained at http://www.apache.org/licenses/LICENSE-2.0.
 * In applying this licence, ECMWF does not waive the privileges and immunities
 * granted to it by virtue of its status as an intergovernmental organisation nor
 * does it submit to any jurisdiction.
 */

#ifndef ODC_ecbuild_config_h
#define ODC_ecbuild_config_h

/* ecbuild info */

#ifndef ECBUILD_VERSION_STR
#define ECBUILD_VERSION_STR "3.7.0"
#endif
#ifndef ECBUILD_VERSION
#define ECBUILD_VERSION "3.7.0"
#endif
#ifndef ECBUILD_MACROS_DIR
#define ECBUILD_MACROS_DIR  "/src/pyodide-recipes/packages/libodc/build/libodc-1.6.3/ecbuild/cmake"
#endif

/* config info */

#define ODC_OS_NAME          "Emscripten-1"
#define ODC_OS_BITS          32
#define ODC_OS_BITS_STR      "32"
#define ODC_OS_STR           "UNKNOWN.32"
#define ODC_OS_VERSION       "1"
#define ODC_SYS_PROCESSOR    "x86"

#define ODC_BUILD_TIMESTAMP  "20260907083354"
#define ODC_BUILD_TYPE       "RelWithDebInfo"

#define ODC_C_COMPILER_ID      "Clang"
#define ODC_C_COMPILER_VERSION "23.0.0"

#define ODC_CXX_COMPILER_ID      "Clang"
#define ODC_CXX_COMPILER_VERSION "23.0.0"

#define ODC_C_COMPILER       "/src/emsdk/emsdk/upstream/emscripten/emcc"
#define ODC_C_FLAGS          " -O2 -g0 -fPIC -fwasm-exceptions -sSUPPORT_LONGJMP=wasm -I/src/cpython/installs/python-3.14.2/include/python3.14 -Oz -O2 -g0 -fPIC -fwasm-exceptions -sSUPPORT_LONGJMP=wasm -I/src/cpython/installs/python-3.14.2/include/python3.14 -Oz -O2 -g0 -fPIC -fwasm-exceptions -sSUPPORT_LONGJMP=wasm -I/src/cpython/installs/python-3.14.2/include/python3.14 -Oz -O2 -g0 -fPIC -fwasm-exceptions -sSUPPORT_LONGJMP=wasm -I/src/cpython/installs/python-3.14.2/include/python3.14 -Oz -O2 -g0 -fPIC -fwasm-exceptions -sSUPPORT_LONGJMP=wasm -I/src/cpython/installs/python-3.14.2/include/python3.14 -Oz -pipe -O2 -g -DNDEBUG"

#define ODC_CXX_COMPILER     "/src/emsdk/emsdk/upstream/emscripten/em++"
#define ODC_CXX_FLAGS        " -O2 -g0 -fPIC -fwasm-exceptions -sSUPPORT_LONGJMP=wasm -Oz -O2 -g0 -fPIC -fwasm-exceptions -sSUPPORT_LONGJMP=wasm -Oz -O2 -g0 -fPIC -fwasm-exceptions -sSUPPORT_LONGJMP=wasm -Oz -O2 -g0 -fPIC -fwasm-exceptions -sSUPPORT_LONGJMP=wasm -Oz -O2 -g0 -fPIC -fwasm-exceptions -sSUPPORT_LONGJMP=wasm -Oz -pipe -Wall -Wextra -Wno-unused-parameter -Wno-unused-variable -Wno-sign-compare -O2 -g -DNDEBUG"

/* Needed for finding per package config files */

#define ODC_INSTALL_DIR       "/src/pyodide-recipes/packages/.libs"
#define ODC_INSTALL_BIN_DIR   "/src/pyodide-recipes/packages/.libs/bin"
#define ODC_INSTALL_LIB_DIR   "/src/pyodide-recipes/packages/.libs/lib"
#define ODC_INSTALL_DATA_DIR  "/src/pyodide-recipes/packages/.libs/share/odc"

#define ODC_DEVELOPER_SRC_DIR "/src/pyodide-recipes/packages/libodc/build/libodc-1.6.3"
#define ODC_DEVELOPER_BIN_DIR "/src/pyodide-recipes/packages/libodc/build/libodc-1.6.3/build"

/* Fortran support */

#if 0

#define ODC_Fortran_COMPILER_ID      ""
#define ODC_Fortran_COMPILER_VERSION ""

#define ODC_Fortran_COMPILER ""
#define ODC_Fortran_FLAGS    ""

#endif

#endif /* ODC_ecbuild_config_h */
