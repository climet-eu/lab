class PBFException(Exception):
    pass


class PBFNotImplemented(PBFException):
    pass
