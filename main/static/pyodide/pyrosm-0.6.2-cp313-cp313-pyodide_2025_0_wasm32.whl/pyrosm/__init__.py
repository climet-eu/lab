from pyrosm.data import get_data, get_path  # drop get_path in the future
from pyrosm.pyrosm import OSM
