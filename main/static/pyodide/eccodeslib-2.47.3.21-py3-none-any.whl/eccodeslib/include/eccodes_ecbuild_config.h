/*
 * (C) Copyright 2011- ECMWF.
 *
 * This software is licensed under the terms of the Apache Licence Version 2.0
 * which can be obtained at http://www.apache.org/licenses/LICENSE-2.0.
 * In applying this licence, ECMWF does not waive the privileges and immunities
 * granted to it by virtue of its status as an intergovernmental organisation nor
 * does it submit to any jurisdiction.
 */

#ifndef ECCODES_ecbuild_config_h
#define ECCODES_ecbuild_config_h

/* ecbuild info */

#ifndef ECBUILD_VERSION_STR
#define ECBUILD_VERSION_STR "3.7.0"
#endif
#ifndef ECBUILD_VERSION
#define ECBUILD_VERSION "3.7.0"
#endif
#ifndef ECBUILD_MACROS_DIR
#define ECBUILD_MACROS_DIR  "/src/pyodide-recipes/packages/libeccodes/build/libeccodes-2.47.3/ecbuild/cmake"
#endif

/* config info */

#define ECCODES_OS_NAME          "Emscripten-1"
#define ECCODES_OS_BITS          32
#define ECCODES_OS_BITS_STR      "32"
#define ECCODES_OS_STR           "UNKNOWN.32"
#define ECCODES_OS_VERSION       "1"
#define ECCODES_SYS_PROCESSOR    "x86"

#define ECCODES_BUILD_TIMESTAMP  "20260906201139"
#define ECCODES_BUILD_TYPE       "RelWithDebInfo"

#define ECCODES_C_COMPILER_ID      "Clang"
#define ECCODES_C_COMPILER_VERSION "23.0.0"

#define ECCODES_CXX_COMPILER_ID      "Clang"
#define ECCODES_CXX_COMPILER_VERSION "23.0.0"

#define ECCODES_C_COMPILER       "/src/emsdk/emsdk/upstream/emscripten/emcc"
#define ECCODES_C_FLAGS          "-fwasm-exceptions -O2 -g0 -fPIC -fwasm-exceptions -sSUPPORT_LONGJMP=wasm -I/src/cpython/installs/python-3.14.2/include/python3.14 -Oz -O2 -g0 -fPIC -fwasm-exceptions -sSUPPORT_LONGJMP=wasm -I/src/cpython/installs/python-3.14.2/include/python3.14 -Oz -O2 -g0 -fPIC -fwasm-exceptions -sSUPPORT_LONGJMP=wasm -I/src/cpython/installs/python-3.14.2/include/python3.14 -Oz -O2 -g0 -fPIC -fwasm-exceptions -sSUPPORT_LONGJMP=wasm -I/src/cpython/installs/python-3.14.2/include/python3.14 -Oz -O2 -g0 -fPIC -fwasm-exceptions -sSUPPORT_LONGJMP=wasm -I/src/cpython/installs/python-3.14.2/include/python3.14 -Oz -pipe -O2 -g -DNDEBUG"

#define ECCODES_CXX_COMPILER     "/src/emsdk/emsdk/upstream/emscripten/em++"
#define ECCODES_CXX_FLAGS        "-fwasm-exceptions -O2 -g0 -fPIC -fwasm-exceptions -sSUPPORT_LONGJMP=wasm -Oz -O2 -g0 -fPIC -fwasm-exceptions -sSUPPORT_LONGJMP=wasm -Oz -O2 -g0 -fPIC -fwasm-exceptions -sSUPPORT_LONGJMP=wasm -Oz -O2 -g0 -fPIC -fwasm-exceptions -sSUPPORT_LONGJMP=wasm -Oz -O2 -g0 -fPIC -fwasm-exceptions -sSUPPORT_LONGJMP=wasm -Oz -pipe -O2 -g -DNDEBUG"

/* Needed for finding per package config files */

#define ECCODES_INSTALL_DIR       "/src/pyodide-recipes/packages/.libs"
#define ECCODES_INSTALL_BIN_DIR   "/src/pyodide-recipes/packages/.libs/bin"
#define ECCODES_INSTALL_LIB_DIR   "/src/pyodide-recipes/packages/.libs/lib"
#define ECCODES_INSTALL_DATA_DIR  "/src/pyodide-recipes/packages/.libs/share/eccodes"

#define ECCODES_DEVELOPER_SRC_DIR "/src/pyodide-recipes/packages/libeccodes/build/libeccodes-2.47.3"
#define ECCODES_DEVELOPER_BIN_DIR "/src/pyodide-recipes/packages/libeccodes/build/libeccodes-2.47.3/build"

/* Fortran support */

#if 0

#define ECCODES_Fortran_COMPILER_ID      ""
#define ECCODES_Fortran_COMPILER_VERSION ""

#define ECCODES_Fortran_COMPILER ""
#define ECCODES_Fortran_FLAGS    ""

#endif

#endif /* ECCODES_ecbuild_config_h */
