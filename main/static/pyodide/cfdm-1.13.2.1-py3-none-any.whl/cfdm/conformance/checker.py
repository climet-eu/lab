import logging

logger = logging.getLogger(__name__)

import numpy as np

from ..functions import is_log_level_debug
from .reporting import Report
from .standardnames import get_all_current_standard_names


class FieldChecker(Report):
    """Contains checks of CF Compliance of Fields.

    Holds methods for checking CF compliance. These methods, whose names
    all start with "_check", check the minimum required for mapping the
    file to CFDM structural elements.

    General CF compliance is only partially checked (e.g. whether or
    not grid mapping variable has a grid_mapping_name attribute is not
    includded) except for coverage of cases of (so far):
      * whether (computed_)standard_name values are valid according
        to specified criteria under Section 3.3. of the Conformance
        document.

    """

    # --------------------- New methods from PR #373 ------------------------

    def _check_standard_name_modifier(self, standard_name):
        """True if a valid modifier or none for a (computed) standard name.

        Also return the standard name with modifiers stripped, as the second
        tuple item.

        .. versionadded:: 1.13.2.0

        """
        # From Appendix C of the Conventions document:
        # https://cfconventions.org/cf-conventions/
        # cf-conventions.html#standard-name-modifiers
        valid_modifiers = {
            "detection_minimum",
            "number_of_observations",
            "standard_error",
            "status_flag",
        }

        # Whitespace-separated modifiers
        # TODO check in case these can be underscore-delimited - this is not
        # covered in the logic below
        parts = standard_name.split()

        length_parts = len(parts)
        if length_parts == 1:
            # No modifier
            return True, standard_name
        elif length_parts == 2:
            base, modifier = parts
            return modifier in valid_modifiers, base

        # More than one modifier is invalid
        return False, parts[0]

    def _check_standard_names(
        self,
        top_ancestor_ncvar,
        ncvar,
        ncvar_attrs,
        direct_parent_ncvar=None,
        no_var_case=False,  # edge cases like cell methods
        check_is_string=True,
        check_is_in_table=True,
        check_is_in_custom_list=False,
    ):
        """Check the `(computed_)standard_name` attribute for validity.

        Checks performed depend on the `check_*` input flags to enable
        or disable given checks and can include a type check and a
        check as to whether the name is contained in the current
        version of the CF Conventions standard name table, else some
        custom list which is expected to be a small subset of names
        from the table.

        These checks are in the context of the variable and at least
        one parent variable (though the parent can be set at the variable
        itself should no parent exist or be relevant).

        .. versionadded:: 1.13.2.0

        :Parameters:

            top_ancestor_ncvar: `str`
                The netCDF variable name of the ancestor variable
                under which to register the bad standard name at
                the top level.

                This is usually the parent variable of the variable
                `ncvar` which has the component problem, but may be
                a higher parent e.g. grandparent variable, when there is
                an intermediate parent variable in which the problem
                should also be registered using `direct_parent_ncvar`,
                or `ncvar` itself, where no parent variable exists or
                is relevant.

            ncvar: `str`
                The netCDF variable name with the component that
                has the bad standard name.

            ncvar_attrs: `str`
                The variable attributes for the netCDF variable, as
                stored in the 'read_vars' dictionary under the
                'variable_attributes' key.

            direct_parent_ncvar: `str` or `None`, optional
                The netCDF variable name of the variable which is the
                direct parent of the variable `ncvar` which has the
                bad standard name, *only to be provided* if a higher
                parent such as a grandparent variable is set as
                the `top_ancestor_ncvar` where it is also important
                to register the problem on the direct parent.

                If `None`, the default, then the bad standard name
                is not not registered for any further (parent)
                variable than `top_ancestor_ncvar`.

            no_var_case: `tuple` or `bool`, optional
                Replaces the input for ncvar_attrs, whose value is then
                ignored, when there is a special case whereby there is
                a standard name defined but not attached directly to a
                variable, for example when a standard name is set in the
                string value of a cell method (an attribute).

                By default this is False and is ignored. If set to a
                value other than False it should be a two-tuple with
                the component to which the name is stored on as a string
                identifier in the first position followed by the
                standard name value stored on it in the second position.

                *Parameter example:*
                  ``["cell_methods", cell_method_name]``

            check_is_string: `bool`, optional
                Whether or not to check if the type of the attribute
                value is a string type. By default this is checked.

            check_is_in_table: `bool`, optional
                Whether or not to check if the attribute value is
                identical to one of the names contained in the
                current version of the CF Conventions standard name
                table (as processed from the canonical XML). By
                default this is checked.

            check_is_in_custom_list: `list`, optional
                Whether or not to check if the attribute value is
                identical to one of the names contained in a list
                of custom values specified. Set to `False` to
                disable this check, else a list of names which is
                a small subset of those in the CF Conventions
                standard name is expected.

                .. note:: If a list is provided for
                          `check_is_in_custom_list` it becomes
                          redundant to check agaist the entire
                          table, therefore `check_is_in_table`
                          must be `False` else a `ValueError`
                          will be raised to reiterate this.

        :Returns:

            `bool` or `None`
                The outcome of the check, where `True` means
                standard name(s) exist and are (all) valid against
                the configured checks, `False` means standard
                name(s) exist but at least one is invalid
                according to those checks, and `None` means no
                (computed_)standard_name was found.

        """
        debug = is_log_level_debug(logger)

        if debug:
            logger.debug(f"Running _check_standard_names() for: {ncvar}")

        if check_is_in_custom_list and check_is_in_table:
            raise ValueError(
                "Can't set both 'check_is_in_custom_list' and "
                "'check_is_in_table'. The former is expected "
                "to check a subset of the full table hence renders the "
                "latter redundant - set it to False with a custom list."
            )

        any_sn_found = False
        invalid_sn_found = False
        for sn_attr in ("standard_name", "computed_standard_name"):
            if no_var_case:
                # 1. Special case whereby we know there's a standard name
                #    but it isn't attached via a variable - notably a cell
                #    method string which contains a bad name.
                sn_value = no_var_case[1]
                attribute_value = {f"{ncvar}:{no_var_case[0]}": sn_value}
            else:
                # 1. Check if there is a (computed_)standard_name property
                sn_value = ncvar_attrs.get(sn_attr)
                attribute_value = {f"{ncvar}:{sn_attr}": sn_value}
            if debug:
                logger.debug(f"Found a {sn_attr} of '{sn_value}' on {ncvar}")

            if not sn_value:
                continue

            # 2. Check that any modifiers are valid
            # Strips off the modifiers in the process
            modifiers_valid, sn_value = self._check_standard_name_modifier(
                sn_value
            )
            if not modifiers_valid:
                self._add_message(
                    top_ancestor_ncvar,
                    ncvar,
                    attribute=attribute_value,
                    message=(
                        f"{sn_attr} attribute",
                        "has a modifier that is not a valid standard "
                        "name modifier",
                    ),
                    conformance="3.3.requirement.1",
                    direct_parent_ncvar=direct_parent_ncvar,
                )
                invalid_sn_found = not modifiers_valid

            any_sn_found = True

            # 3. Check, if requested, if name is a native or numpy string type
            if check_is_string and not (
                isinstance(sn_value, (str, np.str_, np.bytes_))
            ):
                invalid_sn_found = True
                self._add_message(
                    top_ancestor_ncvar,
                    ncvar,
                    attribute=attribute_value,
                    message=(
                        f"{sn_attr} attribute",
                        "has a value that is not a string",
                    ),
                    conformance="3.3.requirement.1",
                    direct_parent_ncvar=direct_parent_ncvar,
                )

            # 4. Check, if requested, that the SN is in the custom list given
            elif (
                check_is_in_custom_list
                and sn_value not in check_is_in_custom_list
            ):
                invalid_sn_found = True
                self._add_message(
                    top_ancestor_ncvar,
                    ncvar,
                    attribute=attribute_value,
                    message=(
                        f"{sn_attr} attribute",
                        "has a value that is not appropriate to "
                        "the context of the variable in question",
                    ),
                    direct_parent_ncvar=direct_parent_ncvar,
                )

            # 5. Check, if requested, if string is in the list of valid names
            elif (
                check_is_in_table
                and sn_value not in get_all_current_standard_names()
            ):
                invalid_sn_found = True
                if self.read_vars["_noncompliance_report"]:
                    logger.warning(
                        f"Detected invalid standard name: '{sn_attr}' of "
                        f"'{sn_value}' for {ncvar}"
                    )
                self._add_message(
                    top_ancestor_ncvar,
                    ncvar,
                    message=(
                        f"{sn_attr} attribute",
                        "has a value that is not a valid name contained "
                        "in the current standard name table",
                    ),
                    attribute=attribute_value,
                    conformance="3.3.requirement.2",
                    direct_parent_ncvar=direct_parent_ncvar,
                )

        # Three possible return signatures to cover existence and validity:
        if not any_sn_found:  # no (computed_)standard_name found
            return
        elif invalid_sn_found:  # found at least one invalid standard name
            return False
        else:  # found at least one and all are valid standard names
            return True
