/*
 * (C) Copyright 2011- ECMWF.
 *
 * This software is licensed under the terms of the Apache Licence Version 2.0
 * which can be obtained at http://www.apache.org/licenses/LICENSE-2.0.
 * In applying this licence, ECMWF does not waive the privileges and immunities
 * granted to it by virtue of its status as an intergovernmental organisation nor
 * does it submit to any jurisdiction.
 */

#ifndef MIR_ecbuild_config_h
#define MIR_ecbuild_config_h

/* ecbuild info */

#ifndef ECBUILD_VERSION_STR
#define ECBUILD_VERSION_STR "3.15.0"
#endif
#ifndef ECBUILD_VERSION
#define ECBUILD_VERSION "3.15.0"
#endif
#ifndef ECBUILD_MACROS_DIR
#define ECBUILD_MACROS_DIR  "/src/pyodide-recipes/packages/libmir/build/libmir-1.29.0/ecbuild/cmake"
#endif

/* config info */

#define MIR_OS_NAME          "Emscripten-1"
#define MIR_OS_BITS          32
#define MIR_OS_BITS_STR      "32"
#define MIR_OS_STR           "UNKNOWN.32"
#define MIR_OS_VERSION       "1"
#define MIR_SYS_PROCESSOR    "x86"

#define MIR_BUILD_TIMESTAMP  "20260907083645"
#define MIR_BUILD_TYPE       "RelWithDebInfo"

#define MIR_C_COMPILER_ID      "Clang"
#define MIR_C_COMPILER_VERSION "23.0.0"

#define MIR_CXX_COMPILER_ID      "Clang"
#define MIR_CXX_COMPILER_VERSION "23.0.0"

#define MIR_C_COMPILER       "/src/emsdk/emsdk/upstream/emscripten/emcc"
#define MIR_C_FLAGS          "-fwasm-exceptions -O2 -g0 -fPIC -fwasm-exceptions -sSUPPORT_LONGJMP=wasm -I/src/cpython/installs/python-3.14.2/include/python3.14 -Oz -O2 -g0 -fPIC -fwasm-exceptions -sSUPPORT_LONGJMP=wasm -I/src/cpython/installs/python-3.14.2/include/python3.14 -Oz -O2 -g0 -fPIC -fwasm-exceptions -sSUPPORT_LONGJMP=wasm -I/src/cpython/installs/python-3.14.2/include/python3.14 -Oz -O2 -g0 -fPIC -fwasm-exceptions -sSUPPORT_LONGJMP=wasm -I/src/cpython/installs/python-3.14.2/include/python3.14 -Oz -O2 -g0 -fPIC -fwasm-exceptions -sSUPPORT_LONGJMP=wasm -I/src/cpython/installs/python-3.14.2/include/python3.14 -Oz -pipe -O2 -g -DNDEBUG"

#define MIR_CXX_COMPILER     "/src/emsdk/emsdk/upstream/emscripten/em++"
#define MIR_CXX_FLAGS        "-fwasm-exceptions -O2 -g0 -fPIC -fwasm-exceptions -sSUPPORT_LONGJMP=wasm -Oz -O2 -g0 -fPIC -fwasm-exceptions -sSUPPORT_LONGJMP=wasm -Oz -O2 -g0 -fPIC -fwasm-exceptions -sSUPPORT_LONGJMP=wasm -Oz -O2 -g0 -fPIC -fwasm-exceptions -sSUPPORT_LONGJMP=wasm -Oz -O2 -g0 -fPIC -fwasm-exceptions -sSUPPORT_LONGJMP=wasm -Oz -pipe -Wall -Wextra -Wno-unused-parameter -Wno-unused-variable -Wno-sign-compare -O2 -g -DNDEBUG"

/* Needed for finding per package config files */

#define MIR_INSTALL_DIR       "/src/pyodide-recipes/packages/.libs"
#define MIR_INSTALL_BIN_DIR   "/src/pyodide-recipes/packages/.libs/bin"
#define MIR_INSTALL_LIB_DIR   "/src/pyodide-recipes/packages/.libs/lib"
#define MIR_INSTALL_DATA_DIR  "/src/pyodide-recipes/packages/.libs/share/mir"

#define MIR_DEVELOPER_SRC_DIR "/src/pyodide-recipes/packages/libmir/build/libmir-1.29.0"
#define MIR_DEVELOPER_BIN_DIR "/src/pyodide-recipes/packages/libmir/build/libmir-1.29.0/build"

/* Fortran support */

#if 0

#define MIR_Fortran_COMPILER_ID      ""
#define MIR_Fortran_COMPILER_VERSION ""

#define MIR_Fortran_COMPILER ""
#define MIR_Fortran_FLAGS    ""

#endif

#endif /* MIR_ecbuild_config_h */
