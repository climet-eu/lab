#pragma once

#define mir_VERSION_STR "1.29.0"
#define mir_VERSION     "1.29.0"

#define mir_VERSION_MAJOR 1
#define mir_VERSION_MINOR 29
#define mir_VERSION_PATCH 0

const char * mir_version();

unsigned int mir_version_int();

const char * mir_version_str();

const char * mir_git_sha1();
