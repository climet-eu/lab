include( CMakeFindDependencyMacro )
find_dependency( eccodes HINTS /src/pyodide-recipes/packages/.libs/lib/cmake/eccodes )
find_dependency( eckit   HINTS /src/pyodide-recipes/packages/.libs/lib/cmake/eckit )
find_dependency( atlas   HINTS /src/pyodide-recipes/packages/.libs/lib/cmake/atlas )

set( MIR_LIBRARIES mir )
