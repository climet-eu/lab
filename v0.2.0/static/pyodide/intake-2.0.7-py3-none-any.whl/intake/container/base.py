class RemoteSource:
    ...


def get_partition(*_, **__):
    pass
