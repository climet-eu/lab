# (C) Copyright 2021 ECMWF.
#
# This software is licensed under the terms of the Apache Licence Version 2.0
# which can be obtained at http://www.apache.org/licenses/LICENSE-2.0.
# In applying this licence, ECMWF does not waive the privileges and immunities
# granted to it by virtue of its status as an intergovernmental organisation
# nor does it submit to any jurisdiction.
#


from .downloader import Downloader, download, robust

import pyodide_http as _pyodide_http
_pyodide_http.patch_all()

__version__ = "0.3.1"

__all__ = [
    "download",
    "Downloader",
    "robust",
]
