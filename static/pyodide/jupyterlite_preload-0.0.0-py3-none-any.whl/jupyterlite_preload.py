import ipyloglite

import pyodide_http
pyodide_http.patch_all()
