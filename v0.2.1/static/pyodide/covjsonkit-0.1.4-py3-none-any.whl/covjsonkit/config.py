from conflator import ConfigModel


class CovjsonKitConfig(ConfigModel):
    param_db: str = "ecmwf"
