from __future__ import annotations

import asyncio
import logging
from typing import TYPE_CHECKING, Any, TypeVar

from typing_extensions import ParamSpec

import pyodide
from zarr.core.config import config

if TYPE_CHECKING:
    from collections.abc import AsyncIterator, Coroutine
    from typing import Any

logger = logging.getLogger(__name__)


P = ParamSpec("P")
T = TypeVar("T")

# From https://github.com/fsspec/filesystem_spec/blob/master/fsspec/asyn.py


class SyncError(Exception):
    pass


def cleanup_resources() -> None:
    pass


def reset_resources_after_fork() -> None:
    pass


def sync(
    coro: Coroutine[Any, Any, T],
    loop: asyncio.AbstractEventLoop | None = None,
    timeout: float | None = None,
) -> T:
    """
    Make loop run coroutine until it returns. Runs in other thread

    Examples
    --------
    >>> sync(async_function(), existing_loop)
    """

    # use JSPI if available
    if pyodide.ffi.can_run_sync():
        if timeout is not None:
            coro = asyncio.wait_for(coro, timeout=timeout)
        return pyodide.ffi.run_sync(coro)

    # otherwise fall back to polling the awaitable once
    # and hoping that it resolves immediately
    try:
        next(coro.__await__())
    except StopIteration as result:
        return result.value
    else:
        raise RuntimeError("could not syncify an awaitable")


async def _collect_aiterator(data: AsyncIterator[T]) -> tuple[T, ...]:
    """
    Collect an entire async iterator into a tuple
    """
    result = [x async for x in data]
    return tuple(result)


def collect_aiterator(data: AsyncIterator[T]) -> tuple[T, ...]:
    """
    Synchronously collect an entire async iterator into a tuple.
    """
    return sync(_collect_aiterator(data))


class SyncMixin:
    def _sync(self, coroutine: Coroutine[Any, Any, T]) -> T:
        # TODO: refactor this to to take *args and **kwargs and pass those to the method
        # this should allow us to better type the sync wrapper
        return sync(
            coroutine,
            timeout=config.get("async.timeout"),
        )

    def _sync_iter(self, async_iterator: AsyncIterator[T]) -> list[T]:
        async def iter_to_list() -> list[T]:
            return [item async for item in async_iterator]

        return self._sync(iter_to_list())
